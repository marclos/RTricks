#' Get Map Data Wrapper
#'
#' Internal function to get map boundaries without using ggplot2::map_data
#' which may not be exported in newer versions.
#'
#' @param region Map region (e.g., "state")
#' @param ... Additional arguments passed to maps::map
#'
#' @return Data frame with map boundaries
#' @keywords internal
get_map_data <- function(region = "state", ...) {
  
  # Get map object from maps package
  map_obj <- maps::map(region, plot = FALSE, fill = TRUE, ...)
  
  # Convert to data frame format
  # This replicates what ggplot2::map_data used to do
  if (requireNamespace("ggplot2", quietly = TRUE)) {
    # If ggplot2 is available, try to use fortify
    tryCatch({
      map_df <- ggplot2::fortify(map_obj)
      return(map_df)
    }, error = function(e) {
      # Fallback if fortify doesn't work
    })
  }
  
  # Manual conversion if fortify not available
  ids <- sapply(strsplit(map_obj$names, ":"), function(x) x[1])
  
  # Create data frame
  map_df <- data.frame(
    long = map_obj$x,
    lat = map_obj$y,
    group = cumsum(is.na(map_obj$x)) + 1,
    region = rep(ids, table(cumsum(is.na(map_obj$x)) + 1)),
    stringsAsFactors = FALSE
  )
  
  # Remove NA rows (pen-up positions)
  map_df <- map_df[!is.na(map_df$long), ]
  
  return(map_df)
}


#' Create Interpolated Heat Map
#'
#' Creates a heat map showing spatial interpolation of climate trends using
#' kriging. Displays continuous surface over state boundaries.
#'
#' @param spatial_data Spatial points data frame (sp format) from
#'   \code{\link{create_spatial_objects}}
#' @param trend_var Name of trend variable to map (e.g., "annual_trend_TMAX")
#' @param title Plot title
#' @param subtitle Plot subtitle (default: NULL)
#' @param state State abbreviation for map boundaries (default: NULL, uses my.state)
#' @param colors Color scheme: "temp" for temperature (blue to red) or
#'   "precip" for precipitation (brown to green to blue) (default: "temp")
#' @param resolution Grid resolution in degrees (default: 0.1, finer = slower)
#' @param buffer Buffer around points in degrees (default: 0.5)
#'
#' @return ggplot2 object
#'
#' @details
#' Uses ordinary kriging to interpolate point data to a continuous surface.
#' Fits a variogram automatically and interpolates to a regular grid.
#'
#' Resolution controls the grid spacing:
#' \itemize{
#'   \item 0.05 - Very fine (slow, very smooth)
#'   \item 0.1 - Fine (recommended for publication)
#'   \item 0.15 - Medium (faster, still good quality)
#'   \item 0.2 - Coarse (fast, for quick previews)
#' }
#'
#' @examples
#' \dontrun{
#' # After creating spatial objects
#' map <- create_heatmap(
#'   trends_sp,
#'   trend_var = "annual_trend_TMAX",
#'   title = "Annual TMAX Trend",
#'   state = "CA"
#' )
#' print(map)
#'
#' # Precipitation map with different colors
#' map_prcp <- create_heatmap(
#'   trends_sp,
#'   "annual_trend_PRCP",
#'   "Precipitation Trend",
#'   state = "CA",
#'   colors = "precip"
#' )
#' }
#'
#' @export
create_heatmap <- function(spatial_data,
                           trend_var,
                           title,
                           subtitle = NULL,
                           state = NULL,
                           colors = "temp",
                           resolution = 0.1,
                           buffer = 0.5) {
  
  # Check for required packages
  if (!requireNamespace("gstat", quietly = TRUE)) {
    stop("Package 'gstat' required for kriging. Install with: install.packages('gstat')")
  }
  if (!requireNamespace("sp", quietly = TRUE)) {
    stop("Package 'sp' required. Install with: install.packages('sp')")
  }
  if (!requireNamespace("stars", quietly = TRUE)) {
    stop("Package 'stars' required. Install with: install.packages('stars')")
  }
  
  # Get state if not provided
  if (is.null(state) && exists("my.state", envir = .GlobalEnv)) {
    state <- get("my.state", envir = .GlobalEnv)
  }
  
  # Check that trend variable exists
  if (!trend_var %in% names(spatial_data)) {
    stop("Variable '", trend_var, "' not found in spatial data. Available: ",
         paste(names(spatial_data), collapse = ", "))
  }
  
  # Remove any NA values in the trend variable
  valid_data <- spatial_data[!is.na(spatial_data[[trend_var]]), ]
  
  if (length(valid_data) == 0) {
    stop("No valid (non-NA) data for variable: ", trend_var)
  }
  
  cat("Creating heat map for", trend_var, "\n")
  cat("  Valid stations:", length(valid_data), "\n")
  
  # Get bounding box
  bbox <- sp::bbox(valid_data)
  xmin <- bbox[1, 1] - buffer
  xmax <- bbox[1, 2] + buffer
  ymin <- bbox[2, 1] - buffer
  ymax <- bbox[2, 2] + buffer
  
  # Create prediction grid
  grid_x <- seq(xmin, xmax, by = resolution)
  grid_y <- seq(ymin, ymax, by = resolution)
  grid_df <- expand.grid(x = grid_x, y = grid_y)
  
  sp::coordinates(grid_df) <- ~x + y
  sp::proj4string(grid_df) <- sp::proj4string(valid_data)
  sp::gridded(grid_df) <- TRUE
  
  cat("  Grid size:", length(grid_x), "x", length(grid_y), "\n")
  
  # Fit variogram
  cat("  Fitting variogram...\n")
  formula <- as.formula(paste(trend_var, "~ 1"))
  
  tryCatch({
    v <- gstat::variogram(formula, valid_data)
    v_fit <- gstat::fit.variogram(v, gstat::vgm("Sph"))
  }, error = function(e) {
    warning("Variogram fitting failed, using default model")
    v_fit <- gstat::vgm(psill = 1, model = "Sph", range = 2, nugget = 0.1)
  })
  
  # Perform kriging
  cat("  Interpolating...\n")
  k <- gstat::krige(formula, valid_data, grid_df, model = v_fit, debug.level = 0)
  
  # Convert to raster/stars for plotting
  k_stars <- stars::st_as_stars(k)
  k_sf <- sf::st_as_sf(k_stars)
  
  # Get state boundaries using our wrapper function
  if (!is.null(state)) {
    state_map <- get_map_data("state", region = tolower(state))
  } else {
    state_map <- get_map_data("state")
  }
  
  # Create plot
  cat("  Creating plot...\n")
  
  p <- ggplot2::ggplot() +
    ggplot2::geom_sf(data = k_sf, ggplot2::aes(fill = var1.pred), color = NA) +
    ggplot2::geom_polygon(
      data = state_map,
      ggplot2::aes(x = long, y = lat, group = group),
      fill = NA, color = "black", size = 0.5
    ) +
    ggplot2::coord_sf(xlim = c(xmin, xmax), ylim = c(ymin, ymax)) +
    ggplot2::labs(
      title = title,
      subtitle = subtitle,
      fill = "Trend"
    ) +
    ggplot2::theme_minimal() +
    ggplot2::theme(
      plot.title = ggplot2::element_text(size = 16, face = "bold"),
      plot.subtitle = ggplot2::element_text(size = 12),
      legend.position = "right"
    )
  
  # Add color scale
  if (colors == "temp") {
    p <- p + ggplot2::scale_fill_viridis_c(
      option = "plasma",
      direction = 1
    )
  } else if (colors == "precip") {
    p <- p + ggplot2::scale_fill_gradient2(
      low = "brown", mid = "white", high = "blue",
      midpoint = 0
    )
  }
  
  cat("[OK] Heat map created\n\n")
  
  return(p)
}
