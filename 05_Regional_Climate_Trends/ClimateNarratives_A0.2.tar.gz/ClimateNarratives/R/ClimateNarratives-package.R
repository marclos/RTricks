#' ClimateNarratives Package
#'
#' Tools for analyzing and visualizing regional climate trends using NOAA GHCN-Daily data.
#'
#' @docType package
#' @name ClimateNarratives
#' @import dplyr tidyr ggplot2
#' @importFrom sf st_as_sf
#' @importFrom sp SpatialPointsDataFrame CRS bbox
#' @importFrom lubridate year month
#' @importFrom gstat variogram fit.variogram krige vgm
#' @importFrom maps map
#' @importFrom stars st_as_stars
#' @importFrom patchwork plot_annotation
#' @importFrom stats lm coef aggregate median sd cor
#' @importFrom utils read.csv write.csv download.file installed.packages
#' @importFrom grDevices dev.off png
#' @importFrom graphics abline hist legend lines par plot points
NULL

#' Download Station Inventory from NOAA
#'
#' Internal function to fetch the complete station inventory from NOAA.
#'
#' @return Data frame with station inventory including metadata
#' @keywords internal
#' @noRd
download_station_inventory <- function() {
  
  cat("Downloading inventory from NOAA (this may take a minute)...\n")
  
  # Read inventory
  inventory <- read.table(
    "https://www.ncei.noaa.gov/pub/data/ghcn/daily/ghcnd-inventory.txt",
    col.names = c("ID", "LATITUDE", "LONGITUDE", "ELEMENT", "FIRSTYEAR", "LASTYEAR")
  )
  
  # Subset for TMAX and active stations
  inventory_TMAX <- subset(inventory, ELEMENT == "TMAX" & LASTYEAR >= 2023)
  
  # Read station metadata
  Stations <- read.fwf(
    "https://www.ncei.noaa.gov/pub/data/ghcn/daily/ghcnd-stations.txt",
    widths = c(11, -1, 8, -1, 9, -1, 6, -1, 2, -1, 30, -1, 3, -1, 3, -1, 5),
    col.names = c("ID", "LATITUDE", "LONGITUDE", "ELEVATION", "STATE", 
                  "NAME", "GSN_FLAG", "HCN_CRN_FLAG", "WMO_ID"),
    fill = TRUE,
    strip.white = TRUE
  )
  
  # Read state names
  States <- read.fwf(
    "https://www.ncei.noaa.gov/pub/data/ghcn/daily/ghcnd-states.txt",
    widths = c(2, -1, 46),
    col.names = c("STATE", "STATE_NAME"),
    fill = TRUE,
    strip.white = TRUE
  )
  
  # Get station metadata with state names
  StationMeta <- subset(Stations, select = c("ID", "LATITUDE", "LONGITUDE", 
                                              "ELEVATION", "STATE", "NAME"))
  StationMeta <- merge(StationMeta, States, by = "STATE")
  
  # Merge with inventory to add date ranges
  inventory_merged <- merge(
    subset(inventory_TMAX, select = c("ID", "FIRSTYEAR", "LASTYEAR")),
    StationMeta,
    by = "ID"
  )
  
  # Remove blank states
  inventory_merged <- subset(inventory_merged, STATE != "" & STATE != " ")
  
  # Calculate record length
  inventory_merged$RECORD_LENGTH <- 
    inventory_merged$LASTYEAR - inventory_merged$FIRSTYEAR + 1
  
  return(inventory_merged)
}


#' Load Previously Saved Station Data
#'
#' Loads station data from RData file created by \code{\link{load_and_save_stations}}.
#'
#' @param verbose Logical. Show progress messages (default = TRUE)
#'
#' @return Invisibly returns character vector of loaded station IDs
#'
#' @details
#' This function loads the \code{all_stations_raw.RData} file from your Data folder
#' and assigns both the \code{station_list} and individual station data frames
#' to your global environment.
#'
#' @section Requirements:
#' Must have previously run \code{\link{load_and_save_stations}} to create the RData file.
#'
#' @examples
#' \dontrun{
#' # After downloading and saving stations
#' load_stations()
#'
#' # Access individual station data
#' head(USC00045123)  # Example station ID
#' }
#'
#' @seealso \code{\link{load_and_save_stations}} to create the RData file
#'
#' @export
load_stations <- function(verbose = TRUE) {
  
  if (!exists("datafolder", envir = .GlobalEnv)) {
    stop("Run initialize_project() first! Variable 'datafolder' not found.")
  }
  
  datafolder <- get("datafolder", envir = .GlobalEnv)
  rdata_file <- paste0(datafolder, "all_stations_raw.RData")
  
  if (!file.exists(rdata_file)) {
    stop("RData file not found: ", rdata_file, "\n",
         "Run load_and_save_stations() first to create this file.")
  }
  
  load(rdata_file, envir = .GlobalEnv)
  
  # Also assign individual stations to global environment
  station_list <- get("station_list", envir = .GlobalEnv)
  for (station_id in names(station_list)) {
    assign(station_id, station_list[[station_id]], envir = .GlobalEnv)
  }
  
  if (verbose) {
    cat("[OK] Loaded", length(station_list), "stations from", rdata_file, "\n")
  }
  
  invisible(names(station_list))
}


#' @keywords internal
.onAttach <- function(libname, pkgname) {
  packageStartupMessage(
    "===========================================================\n",
    " ClimateNarratives v0.2.0\n",
    "===========================================================\n",
    " Regional Climate Trends Analysis and Visualization\n",
    " Type ?ClimateNarratives for help\n",
    "===========================================================\n",
    "\n",
    " Quick Start:\n",
    "   initialize_project('CA')  # Set up for California\n",
    "   ?initialize_project       # See documentation\n",
    "===========================================================\n"
  )
}
