# ClimateNarratives v0.2.0

Regional Climate Trends Analysis and Visualization using NOAA GHCN-Daily data.

## Version 0.2.0 Changes

### Fixed
- **Coordinate loading issue**: Fixed `process_all_stations()` to properly retrieve station coordinates from `station_inventory`
- **map_data compatibility**: Replaced deprecated `ggplot2::map_data()` with `maps::map()` + `fortify()` wrapper
- **Package corruption**: Improved installation robustness

### Added
- `process_all_stations()` - Process all stations to calculate climate trends
- `create_spatial_objects()` - Convert trend data to spatial formats (sf and sp)
- `create_heatmap()` - Create interpolated heat maps using kriging
- Diagnostic messages to help identify coordinate/inventory issues

### Changed
- Version numbering reset to 0.2.0 for clarity
- Improved error messages and debugging output

## Quick Start

```r
# Install
install.packages("ClimateNarratives_0.2.tar.gz", repos = NULL, type = "source")

# Or with devtools
devtools::install_local("ClimateNarratives_0.2.tar.gz")

# Load
library(ClimateNarratives)

# Initialize project
initialize_project("CA")

# Select and download stations
select_stations(n = 50)
download_stations()
load_and_save_stations()

# Process for spatial analysis
trends <- process_all_stations()
create_spatial_objects(trends)

# Create heat maps
map <- create_heatmap(
  trends_sp,
  trend_var = "annual_trend_TMAX",
  title = "Temperature Trend",
  state = my.state
)
print(map)
```

## Installation from Source

```r
# Option 1: Direct install
install.packages("ClimateNarratives_0.2.tar.gz", repos = NULL, type = "source")

# Option 2: With devtools
devtools::install_local("ClimateNarratives_0.2.tar.gz")

# Option 3: From directory
devtools::install("path/to/ClimateNarratives")
```

## Requirements

- R >= 4.0.0
- Required packages: dplyr, tidyr, ggplot2, sf, sp, gstat, stars, maps, viridis, lubridate, patchwork

## Troubleshooting

### "No valid coordinates found in trends data"

This means coordinates aren't being loaded properly. Fix:

```r
# Make sure you have inventory loaded
# Option 1: Use initialize_project() which loads my.inventory
initialize_project("CA")

# Option 2: Make sure station_inventory exists from load_and_save_stations()
load_and_save_stations()  # This creates station_inventory

# Then process
trends <- process_all_stations()  # Should now have coordinates
```

### Package won't load or gives "internal error"

Try clean reinstall:

```r
# Remove old version
remove.packages("ClimateNarratives")

# Clear R environment
q()  # Quit R completely
# Restart R

# Install fresh
install.packages("ClimateNarratives_0.2.tar.gz", repos = NULL, type = "source")
```

## Package Contents

### Functions

**Setup:**
- `initialize_project()` - Set up project structure and download station inventory
- `set_config()` - Quick configuration change

**Data Acquisition:**
- `select_stations()` - Filter high-quality weather stations
- `download_stations()` - Fetch data from NOAA
- `load_and_save_stations()` - Process and save downloaded data
- `load_stations()` - Load previously saved data

**Data Processing:**
- `fixDates.fun()` - Convert NOAA date format
- `fixValues.fun()` - Convert NOAA units
- `coverage.fun()` - Calculate data coverage
- `MonthlyValues.fun()` - Aggregate to monthly data
- `MonthlyNormals.fun()` - Calculate 1961-1990 normals
- `MonthlyAnomalies.fun()` - Calculate anomalies
- `monthlyTrend.fun()` - Calculate monthly trends

**Spatial Analysis:**
- `process_all_stations()` - Calculate climate trends for all stations
- `create_spatial_objects()` - Convert to sf/sp spatial formats
- `create_heatmap()` - Create interpolated heat maps with kriging

## Citation

```
Los Huertos, M. (2025). ClimateNarratives: Regional Climate Trends Analysis 
and Visualization. R package version 0.2.0.
```

## License

GPL-3

## Data Source

NOAA National Centers for Environmental Information  
Global Historical Climatology Network - Daily (GHCN-Daily)  
https://www.ncei.noaa.gov/products/land-based-station/global-historical-climatology-network-daily
