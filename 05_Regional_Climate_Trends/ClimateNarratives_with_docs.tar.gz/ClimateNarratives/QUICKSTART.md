# Quick Start Guide - ClimateNarratives Package

This guide gets you up and running with climate analysis in 5 minutes.

## Installation (One Time)

### Method 1: From GitHub (Easiest)

```r
# Install devtools if needed
install.packages("devtools")

# Install ClimateNarratives
devtools::install_github("yourusername/ClimateNarratives")
```

### Method 2: From Downloaded Source

```r
# If you downloaded the package folder
install.packages("path/to/ClimateNarratives", repos = NULL, type = "source")
```

### Method 3: For RStudio Server

```r
# Clone or download to your server, then:
setwd("/path/to/ClimateNarratives")
source("install_package.R")
```

## Your First Analysis (5 Steps)

### Step 1: Load Package

```r
library(ClimateNarratives)
```

### Step 2: Set Up Project (Pick Your State)

```r
# Initialize for your state
initialize_project("CA")  # California
# or: initialize_project("TX")  # Texas
# or: initialize_project("NY")  # New York

# With custom folder location:
initialize_project("CA", path = "~/Documents/MyClimateProject")
```

**What this does:**
- Creates `Data/`, `Output/`, `Figures/` folders
- Downloads station list from NOAA
- Sets up workspace variables

### Step 3: Select Weather Stations

```r
# Choose 50 high-quality stations
select_stations(n = 50)
```

**What this does:**
- Filters for stations with 50+ years of data
- Selects best stations for your state
- Saves selection to `Data/` folder

### Step 4: Download Data (Takes 10-30 min)

```r
# Download from NOAA - run once!
download_stations()

# Then process and save
load_and_save_stations()
```

**What this does:**
- Downloads weather data from NOAA
- Processes into R format
- Cleans up temporary files

### Step 5: Analyze and Visualize

```r
# Calculate climate trends
trends <- process_all_stations()

# Create spatial objects
create_spatial_objects(trends)

# Make a heat map!
map <- create_heatmap(
  trends_sp,
  trend_var = "annual_trend_TMAX",
  title = "Annual Maximum Temperature Trend",
  state = my.state
)

print(map)

# Save high-resolution version
ggsave(paste0(figuresfolder, "my_climate_map.png"), 
       map, width = 10, height = 8, dpi = 300)
```

## That's It!

You now have:
✅ Downloaded real climate data
✅ Calculated warming trends
✅ Created professional heat map
✅ Publication-quality figure

## Next Steps

### Explore Seasonal Patterns

```r
# Summer warming
map_summer <- create_heatmap(trends_sp, "summer_trend_TMAX",
                             "Summer Warming Trend", state = my.state)

# Winter warming  
map_winter <- create_heatmap(trends_sp, "winter_trend_TMAX",
                             "Winter Warming Trend", state = my.state)
```

### Compare Temperature vs Precipitation

```r
# Precipitation trends (note: colors = "precip")
map_prcp <- create_heatmap(trends_sp, "annual_trend_PRCP",
                           "Precipitation Trend", 
                           state = my.state, colors = "precip")
```

### Combine Multiple Maps

```r
library(patchwork)

# Create 4-panel seasonal comparison
seasonal <- (map_winter | map_spring) / (map_summer | map_fall)
print(seasonal)

ggsave("seasonal_comparison.png", seasonal, width = 12, height = 10, dpi = 300)
```

## Workflow for Different States

```r
# Analyze multiple states
states <- c("CA", "NV", "AZ", "OR")

for (state in states) {
  initialize_project(state, path = paste0("~/Climate_", state))
  select_stations(n = 50)
  download_stations()
  load_and_save_stations()
  
  trends <- process_all_stations()
  create_spatial_objects(trends)
  
  map <- create_heatmap(trends_sp, "annual_trend_TMAX",
                        paste(state, "Warming Trend"),
                        state = state)
  
  ggsave(paste0("map_", state, ".png"), map, width = 10, height = 8, dpi = 300)
}
```

## Getting Help

```r
# Package overview
?ClimateNarratives

# Function help
?initialize_project
?create_heatmap
?process_all_stations

# See all functions
help(package = "ClimateNarratives")

# Run examples
example(select_stations)
```

## Typical Project Workflow

```
Session 1 (Setup - do once):
  initialize_project()
  select_stations()
  download_stations()
  load_and_save_stations()

Session 2+ (Analysis - as needed):
  load_stations()  # Load previously saved data
  trends <- process_all_stations()
  create_spatial_objects(trends)
  # Create maps, analyze patterns, etc.
```

## File Structure After Setup

```
YourProject/
├── Data/
│   ├── stations.active.oldest.csv       # All available stations
│   ├── selected_inventory_CA.csv        # Your selected 50 stations
│   ├── downloaded_inventory.csv         # Successfully downloaded
│   ├── all_stations_raw.RData          # All station data (loads fast!)
│   └── spatial_trends_CA.RData         # Processed trends
├── Output/
│   └── (your analysis results)
└── Figures/
    └── (your heat maps - publication ready!)
```

## Troubleshooting

**"Variable not found" error**
→ Run `initialize_project()` first

**Download fails**
→ Check internet connection, try again with `download_stations()`

**Heat map looks weird**
→ Need 20+ stations for good interpolation
→ Try adjusting `resolution` parameter

**Out of memory**
→ Reduce number of stations with `select_stations(n = 30)`

## Common Tasks

### Just load existing data

```r
library(ClimateNarratives)
setwd("~/path/to/project")
my.state <- "CA"
datafolder <- "Data/"
figuresfolder <- "Figures/"

load_stations()
```

### Start fresh project

```r
library(ClimateNarratives)
initialize_project("TX", path = "~/NewTexasProject")
# ... follow 5 steps above
```

### Update with new data

```r
# Re-download for recently added data
download_stations()
load_and_save_stations()
trends <- process_all_stations()
```

## Ready to Go!

You're all set to analyze climate trends. Start with your state and explore the data!

For more examples, see:
- `vignette("getting-started")`
- README.md
- Help files: `?initialize_project`
