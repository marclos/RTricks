#!/usr/bin/env Rscript

# =============================================================================
# ClimateNarratives Package Installation Script
# =============================================================================
# This script helps you install the ClimateNarratives package from source
#
# USAGE:
#   From R/RStudio:
#     source("install_package.R")
#
#   From command line:
#     Rscript install_package.R
# =============================================================================

cat("\n")
cat("===========================================================\n")
cat("  ClimateNarratives Package Installer\n")
cat("===========================================================\n\n")

# Check if devtools is available
if (!requireNamespace("devtools", quietly = TRUE)) {
  cat("Installing devtools package...\n")
  install.packages("devtools")
}

# Check if roxygen2 is available (for documentation)
if (!requireNamespace("roxygen2", quietly = TRUE)) {
  cat("Installing roxygen2 package...\n")
  install.packages("roxygen2")
}

cat("\nBuilding package documentation...\n")
devtools::document()

cat("\nChecking package...\n")
devtools::check()

cat("\nInstalling package...\n")
devtools::install()

cat("\n")
cat("===========================================================\n")
cat("  Installation Complete!\n")
cat("===========================================================\n")
cat("\nTo get started:\n")
cat("  library(ClimateNarratives)\n")
cat("  ?ClimateNarratives\n")
cat("  initialize_project('CA')\n")
cat("===========================================================\n\n")
