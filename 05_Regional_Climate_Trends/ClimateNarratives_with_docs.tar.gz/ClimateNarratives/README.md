# ClimateNarratives

An R package for analyzing and visualizing regional climate trends using NOAA GHCN-Daily data. Designed for teaching R programming through climate science.

## Features

- 📊 Download and process weather station data from NOAA
- 🔍 Automated data quality filtering
- 📈 Calculate climate trends and anomalies
- 🗺️ Create spatial heat maps with kriging interpolation
- 📚 Comprehensive documentation and examples
- 🎓 Pedagogical focus for learning R

## Installation

### From GitHub (Recommended)

```r
# Install devtools if you don't have it
install.packages("devtools")

# Install ClimateNarratives from GitHub
devtools::install_github("yourusername/ClimateNarratives")
```

### For RStudio Server

```r
# If you have git access on your RStudio Server:
devtools::install_git("https://github.com/yourusername/ClimateNarratives.git")

# Or download and install from source:
# 1. Download the repository as a ZIP file
# 2. Upload to your RStudio Server
# 3. Install:
install.packages("path/to/ClimateNarratives.zip", repos = NULL, type = "source")
```

## Quick Start

### 1. Initialize Your Project

```r
library(ClimateNarratives)

# Set up project for California
initialize_project("CA")

# Or with custom path
initialize_project("CA", path = "~/Documents/MyClimateProject")
```

This creates:
- `Data/` folder for weather data
- `Output/` folder for results
- `Figures/` folder for plots
- Sets global variables: `my.state`, `my.inventory`, `datafolder`, `figuresfolder`

### 2. Select High-Quality Stations

```r
# Select 50 stations with good data quality
select_stations(n = 50)

# Or with stricter criteria
select_stations(n = 30, min_years = 70, min_last_year = 2022)
```

### 3. Download Data

```r
# Download data from NOAA (takes 10-30 minutes)
download_stations()
```

### 4. Process Data

```r
# Load CSV files and save as RData
load_and_save_stations(cleanup = TRUE)  # cleanup removes CSV files to save space

# Or load previously saved data
load_stations()
```

### 5. Analyze Trends

```r
# Process all stations and calculate trends
trends <- process_all_stations()

# Create spatial objects for mapping
spatial_objects <- create_spatial_objects(trends)
```

### 6. Create Heat Maps

```r
# Annual maximum temperature trend
map <- create_heatmap(
  trends_sp,
  trend_var = "annual_trend_TMAX",
  title = "Annual Maximum Temperature Trend - California",
  state = "CA"
)

print(map)
ggsave("california_tmax_trend.png", map, width = 10, height = 8, dpi = 300)
```

## Complete Workflow Example

```r
library(ClimateNarratives)

# 1. Setup (one time)
initialize_project("TX", path = "~/ClimateTexas")
select_stations(n = 50)
download_stations()
load_and_save_stations()

# 2. Analysis
trends <- process_all_stations()
create_spatial_objects(trends)

# 3. Visualization
map_tmax <- create_heatmap(trends_sp, "annual_trend_TMAX", 
                           "Texas Annual TMAX Trend", state = "TX")
map_tmin <- create_heatmap(trends_sp, "annual_trend_TMIN",
                           "Texas Annual TMIN Trend", state = "TX")
map_prcp <- create_heatmap(trends_sp, "annual_trend_PRCP",
                           "Texas Annual Precipitation Trend", 
                           state = "TX", colors = "precip")

# Save all maps
ggsave("texas_tmax.png", map_tmax, width = 10, height = 8, dpi = 300)
ggsave("texas_tmin.png", map_tmin, width = 10, height = 8, dpi = 300)
ggsave("texas_prcp.png", map_prcp, width = 10, height = 8, dpi = 300)
```

## Available Functions

### Setup & Data
- `initialize_project()` - Set up project structure and paths
- `set_config()` - Quick configuration without re-download
- `select_stations()` - Filter high-quality weather stations
- `download_stations()` - Fetch data from NOAA
- `load_and_save_stations()` - Process and save data
- `load_stations()` - Load previously saved data

### Data Processing
- `fixDates.fun()` - Convert NOAA date format to R dates
- `fixValues.fun()` - Convert NOAA units to standard units
- `coverage.fun()` - Calculate data coverage percentage
- `MonthlyValues.fun()` - Aggregate daily to monthly data
- `MonthlyNormals.fun()` - Calculate 1961-1990 climate normals
- `MonthlyAnomalies.fun()` - Calculate anomalies from normals
- `monthlyTrend.fun()` - Calculate monthly trend statistics

### Analysis
- `process_all_stations()` - Process all stations for spatial analysis

### Visualization
- `create_spatial_objects()` - Convert to sf/sp spatial formats
- `create_heatmap()` - Create interpolated heat maps with kriging

## Data Structure

After processing, you'll have:

```
MyProject/
├── Data/
│   ├── stations.active.oldest.csv       # All available stations
│   ├── selected_inventory_CA.csv        # Your selected stations
│   ├── downloaded_inventory.csv         # Successfully downloaded
│   ├── all_stations_raw.RData          # Raw station data
│   └── spatial_trends_CA.RData         # Processed trend data
├── Output/
│   └── (analysis results)
└── Figures/
    └── (heat maps and plots)
```

## Understanding the Data

### Climate Normals
The package uses the 1961-1990 period as the baseline "climate normal" following WMO standards.

### Anomalies
Anomaly = Observed value - Climate normal
- Positive anomaly = warmer/wetter than normal
- Negative anomaly = cooler/drier than normal

### Trends
Trends are reported as change per century (°C/century or mm/century) using linear regression.

## Getting Help

```r
# Package documentation
help(package = "ClimateNarratives")

# Function help
?initialize_project
?create_heatmap

# Examples
example(select_stations)
```

## Troubleshooting

### "Variable not found" errors
Make sure you've run `initialize_project()` first. This sets up all required global variables.

### Download fails
- Check internet connection
- NOAA servers may be temporarily unavailable
- Try again with `download_stations()`

### Heat maps look odd
- Need at least 20-30 stations for good interpolation
- Check that stations have good spatial coverage
- Try adjusting `resolution` parameter in `create_heatmap()`

## Requirements

- R >= 4.0.0
- RStudio (recommended)
- Internet connection for downloading data
- ~100-500 MB disk space per state

## Citation

If you use this package in your work, please cite:

```
Los Huertos, M. (2025). ClimateNarratives: Regional Climate Trends Analysis 
and Visualization. R package version 0.7.0.
https://github.com/yourusername/ClimateNarratives
```

## License

GPL-3

## Contributing

Issues and pull requests welcome at: https://github.com/yourusername/ClimateNarratives/issues

## Acknowledgments

- NOAA National Centers for Environmental Information for GHCN-Daily data
- Built for teaching R programming through climate science
