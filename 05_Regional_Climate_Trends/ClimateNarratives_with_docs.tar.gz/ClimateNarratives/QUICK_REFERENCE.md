# ClimateNarratives - Quick Reference Card

## Installation (One Time)

```r
devtools::install_github("YOUR_USERNAME/ClimateNarratives")
```

## Basic Workflow

### 1. Setup Project
```r
library(ClimateNarratives)
initialize_project("CA")  # Your state code
```

### 2. Select Stations
```r
select_stations(n = 50)
```

### 3. Download Data
```r
download_stations()  # Takes 10-30 min
load_and_save_stations()
```

### 4. Analyze
```r
trends <- process_all_stations()
create_spatial_objects(trends)
```

### 5. Visualize
```r
map <- create_heatmap(trends_sp, "annual_trend_TMAX", 
                      "Your Title", state = my.state)
print(map)
ggsave("my_map.png", map, width = 10, height = 8, dpi = 300)
```

## Common Functions

| Function | Purpose |
|----------|---------|
| `initialize_project(state, path)` | Set up folders and variables |
| `select_stations(n, min_years)` | Choose quality stations |
| `download_stations()` | Fetch data from NOAA |
| `load_and_save_stations()` | Process downloaded data |
| `load_stations()` | Load previously saved data |
| `process_all_stations()` | Calculate all trends |
| `create_spatial_objects(trends)` | Prepare for mapping |
| `create_heatmap(...)` | Make interpolated maps |

## Key Variables (After initialize_project)

- `my.state` - Your state abbreviation
- `my.inventory` - Available stations data frame
- `datafolder` - Path to Data/ folder
- `figuresfolder` - Path to Figures/ folder
- `trends_sf`, `trends_sp` - Spatial trend objects

## Heat Map Variables

**Temperature Trends:**
- `annual_trend_TMAX` - Annual max temp
- `annual_trend_TMIN` - Annual min temp
- `winter_trend_TMAX` - Winter max
- `summer_trend_TMAX` - Summer max
- (also spring, fall)

**Precipitation:**
- `annual_trend_PRCP` - Annual precipitation
- `winter_trend_PRCP`, etc.

## Getting Help

```r
?initialize_project    # Function help
?ClimateNarratives    # Package overview
help(package = "ClimateNarratives")  # All functions
example(select_stations)  # Run examples
```

## File Locations

After setup, your files are in:
- `Data/` - Downloaded weather data
- `Figures/` - Your heat maps
- `Output/` - Analysis results

## Troubleshooting

**"Variable not found"**
→ Run `initialize_project()` first

**Download fails**
→ Run `download_stations()` again (resumes)

**Need to restart**
```r
library(ClimateNarratives)
my.state <- "CA"
datafolder <- "Data/"
figuresfolder <- "Figures/"
load_stations()
```

## Tips

- Use `n = 50` stations for good heat maps
- Set `cleanup = TRUE` to save disk space
- Resolution `0.1` is good for most states
- Use `colors = "precip"` for precipitation maps
- Save maps with `ggsave()` at `dpi = 300`

## Complete Example

```r
library(ClimateNarratives)
initialize_project("TX", path = "~/TexasClimate")
select_stations(n = 50)
download_stations()
load_and_save_stations()

trends <- process_all_stations()
create_spatial_objects(trends)

map <- create_heatmap(trends_sp, "annual_trend_TMAX",
                      "Texas Warming Trend", state = "TX")
ggsave("texas_warming.png", map, width = 10, height = 8, dpi = 300)
```

---
Save this as a reference while working!
