#' Initialize Climate Narratives Project
#'
#' This is the main setup function that configures your entire project workspace.
#' It creates the directory structure, downloads station inventory, and sets up
#' global variables needed for all subsequent analysis.
#'
#' @param state Two-letter state abbreviation (e.g., "CA", "NV", "TX")
#' @param path Base path for the project. Defaults to current working directory.
#'   Can be relative (e.g., "~/MyClimateProject") or absolute.
#'
#' @return Invisibly returns a list containing:
#' \itemize{
#'   \item state - The state abbreviation
#'   \item paths - Named list of project directories (root, data, output, figures)
#'   \item inventory - Data frame of available weather stations
#'   \item datafolder - Path to Data folder (with trailing slash)
#'   \item figuresfolder - Path to Figures folder (with trailing slash)
#' }
#'
#' @details
#' This function creates three subdirectories:
#' \itemize{
#'   \item Data/ - For downloaded weather data and processed files
#'   \item Output/ - For analysis results and tables
#'   \item Figures/ - For plots and heat maps
#' }
#'
#' The following variables are created in your global environment:
#' \itemize{
#'   \item \code{my.state} - Your state abbreviation
#'   \item \code{my.inventory} - Data frame of available stations
#'   \item \code{datafolder} - Path to Data/ (for reading/writing data)
#'   \item \code{figuresfolder} - Path to Figures/ (for saving plots)
#' }
#'
#' @examples
#' \dontrun{
#' # Basic setup for California in current directory
#' initialize_project("CA")
#'
#' # Setup with custom path
#' initialize_project("CA", path = "~/Documents/ClimateProject")
#'
#' # Setup and capture return values
#' project <- initialize_project("TX", path = "C:/Research/Climate")
#' }
#'
#' @seealso
#' \code{\link{select_stations}} to choose high-quality stations
#' \code{\link{download_stations}} to fetch data from NOAA
#'
#' @export
initialize_project <- function(state, path = getwd()) {
  
  cat("\n")
  cat("===========================================================\n")
  cat("  Climate Narratives Project Setup v0.7.0\n")
  cat("===========================================================\n")
  cat("  Enhanced for improved spatial analysis\n")
  cat("===========================================================\n")
  cat("  State:", state, "\n")
  cat("  Path:", path, "\n")
  cat("===========================================================\n\n")
  
  # Validate state
  if (missing(state)) {
    stop("Please provide a state abbreviation (e.g., 'CA', 'TX')")
  }
  
  if (nchar(state) != 2) {
    stop("State must be a 2-letter abbreviation (e.g., 'CA', 'NV', 'TX')")
  }
  state <- toupper(state)
  
  # Expand path
  path <- normalizePath(path, mustWork = FALSE)
  
  # Create directory structure
  dirs <- list(
    root = path,
    data = file.path(path, "Data"),
    output = file.path(path, "Output"),
    figures = file.path(path, "Figures")
  )
  
  cat("Creating directories...\n")
  for (dir_name in names(dirs)) {
    if (dir_name == "root") next
    if (!dir.exists(dirs[[dir_name]])) {
      dir.create(dirs[[dir_name]], recursive = TRUE)
      cat("  [OK] Created:", dirs[[dir_name]], "\n")
    } else {
      cat("  [OK] Exists:", dirs[[dir_name]], "\n")
    }
  }
  
  # Set folder path variables
  datafolder <- paste0(dirs$data, "/")
  figuresfolder <- paste0(dirs$figures, "/")
  
  assign("datafolder", datafolder, envir = .GlobalEnv)
  assign("figuresfolder", figuresfolder, envir = .GlobalEnv)
  
  cat("\n[OK] Set folder variables:\n")
  cat("     datafolder    =", datafolder, "\n")
  cat("     figuresfolder =", figuresfolder, "\n")
  
  # Download station inventory
  inventory_file <- file.path(dirs$data, "stations.active.oldest.csv")
  
  if (!file.exists(inventory_file)) {
    cat("\nDownloading station inventory from NOAA...\n")
    tryCatch({
      inventory <- download_station_inventory()
      write.csv(inventory, inventory_file, row.names = FALSE)
      cat("[OK] Saved station inventory\n")
    }, error = function(e) {
      stop("Failed to download inventory: ", e$message)
    })
  } else {
    cat("\n[OK] Station inventory already exists\n")
    inventory <- read.csv(inventory_file, stringsAsFactors = FALSE)
  }
  
  # Subset for selected state
  my.inventory <- subset(inventory, STATE == state)
  
  if (nrow(my.inventory) == 0) {
    cat("\nAvailable states:\n")
    print(sort(unique(inventory$STATE)))
    stop("No stations found for state: ", state)
  }
  
  cat("\n[OK] Found", nrow(my.inventory), "potential stations for", state, "\n\n")
  
  # Store in global environment
  assign("my.state", state, envir = .GlobalEnv)
  assign("my.inventory", my.inventory, envir = .GlobalEnv)
  
  cat("===========================================================\n")
  cat("  Setup Complete!\n")
  cat("===========================================================\n")
  cat("  Variables created in global environment:\n")
  cat("    * my.state       =", state, "\n")
  cat("    * my.inventory   =", nrow(my.inventory), "potential stations\n")
  cat("    * datafolder     =", datafolder, "\n")
  cat("    * figuresfolder  =", figuresfolder, "\n")
  cat("===========================================================\n")
  cat("  Next step:\n")
  cat("    select_stations(n = 50)\n")
  cat("===========================================================\n\n")
  
  invisible(list(
    state = state,
    paths = dirs,
    inventory = my.inventory,
    datafolder = datafolder,
    figuresfolder = figuresfolder
  ))
}


#' Set Project Configuration
#'
#' A convenience function to quickly set or change the state and path
#' without re-downloading inventory data.
#'
#' @param state Two-letter state abbreviation
#' @param path Project base path
#'
#' @return Invisibly returns the project configuration list
#'
#' @examples
#' \dontrun{
#' # Quick configuration
#' set_config("CA", "~/ClimateProject")
#' }
#'
#' @export
set_config <- function(state, path = getwd()) {
  initialize_project(state, path)
}
