#' Load Stations and Save to RData with Cleanup
#'
#' Loads all downloaded station CSV files, combines them into a list,
#' saves to efficient RData format, and optionally removes temporary files
#' to save disk space.
#'
#' @param cleanup Logical. Remove .gz and .csv files after saving (default = TRUE)
#' @param verbose Logical. Show progress messages (default = TRUE)
#'
#' @return Invisibly returns character vector of successfully loaded station IDs
#'
#' @details
#' This function:
#' \enumerate{
#'   \item Reads each station's CSV file
#'   \item Stores data in a list structure
#'   \item Saves to compressed RData format
#'   \item Optionally removes temporary files
#' }
#'
#' The RData format is:
#' \itemize{
#'   \item 5-10x smaller than CSV files
#'   \item Faster to load
#'   \item Preserves R data types
#' }
#'
#' With \code{cleanup = TRUE}, this function can free 100-500 MB of disk space
#' per state while preserving all data in the more efficient RData format.
#'
#' @section Files Created:
#' \code{Data/all_stations_raw.RData} - Contains station_list and station_inventory
#'
#' @section Global Variables:
#' Assigns to global environment:
#' \itemize{
#'   \item \code{station_list} - Named list of all station data frames
#'   \item Individual station data frames (e.g., USC00045123)
#' }
#'
#' @examples
#' \dontrun{
#' # After download_stations()
#' load_and_save_stations()
#'
#' # Keep CSV files
#' load_and_save_stations(cleanup = FALSE)
#' }
#'
#' @seealso
#' \code{\link{download_stations}} to download the data first
#' \code{\link{load_stations}} to load previously saved data
#'
#' @export
load_and_save_stations <- function(cleanup = TRUE, verbose = TRUE) {
  
  if (!exists("datafolder", envir = .GlobalEnv)) {
    stop("Run initialize_project() first! Variable 'datafolder' not found.")
  }
  
  datafolder <- get("datafolder", envir = .GlobalEnv)
  inventory_file <- paste0(datafolder, "downloaded_inventory.csv")
  
  if (!file.exists(inventory_file)) {
    stop("No downloaded_inventory.csv found. Run download_stations() first.")
  }
  
  station_inventory <- read.csv(inventory_file, stringsAsFactors = FALSE)
  
  if (verbose) {
    cat("===========================================================\n")
    cat("  Loading and Processing Station Data\n")
    cat("===========================================================\n")
  }
  
  col_names <- c("ID", "DATE", "ELEMENT", "VALUE", 
                 "M-FLAG", "Q-FLAG", "S-FLAG", "OBS-TIME")
  
  loaded_count <- 0
  failed_count <- 0
  station_list <- list()
  files_to_remove <- character(0)
  
  for (i in 1:nrow(station_inventory)) {
    
    station_id <- station_inventory$ID[i]
    csv_file <- paste0(datafolder, station_id, ".csv")
    gz_file <- paste0(datafolder, station_id, ".csv.gz")
    
    if (!file.exists(csv_file)) {
      if (verbose) warning("File not found: ", csv_file)
      failed_count <- failed_count + 1
      next
    }
    
    tryCatch({
      station_data <- read.csv(csv_file, stringsAsFactors = FALSE)
      
      # Store in list
      station_list[[station_id]] <- station_data
      
      # Also assign to global environment
      assign(station_id, station_data, envir = .GlobalEnv)
      
      loaded_count <- loaded_count + 1
      
      # Track files for cleanup
      if (cleanup) {
        if (file.exists(csv_file)) files_to_remove <- c(files_to_remove, csv_file)
        if (file.exists(gz_file)) files_to_remove <- c(files_to_remove, gz_file)
      }
      
      if (verbose) {
        cat(sprintf("[%d/%d] %s (%s records)\n", 
                    i, nrow(station_inventory), station_id, 
                    format(nrow(station_data), big.mark = ",")))
      }
      
    }, error = function(e) {
      warning("Failed to load ", station_id, ": ", conditionMessage(e))
      failed_count <- failed_count + 1
    })
  }
  
  # Save all stations to RData
  rdata_file <- paste0(datafolder, "all_stations_raw.RData")
  save(station_list, station_inventory, file = rdata_file)
  
  if (verbose) {
    cat("\n[OK] Saved", loaded_count, "stations to:", rdata_file, "\n")
    cat("     File size:", 
        format(file.info(rdata_file)$size / 1024^2, digits = 2), "MB\n")
  }
  
  # Cleanup if requested
  if (cleanup && length(files_to_remove) > 0) {
    if (verbose) {
      cat("\nCleaning up temporary files...\n")
      cat("  Removing", length(files_to_remove), ".csv and .gz files\n")
    }
    
    space_saved <- sum(file.info(files_to_remove)$size, na.rm = TRUE)
    file.remove(files_to_remove)
    
    if (verbose) {
      cat("  Freed up", 
          format(space_saved / 1024^2, digits = 2), "MB of disk space\n")
    }
  }
  
  if (verbose) {
    cat("===========================================================\n")
    cat("Loading Summary:\n")
    cat("===========================================================\n")
    cat("  Successfully loaded:", loaded_count, "stations\n")
    cat("  Failed to load:", failed_count, "stations\n")
    cat("  Saved to RData:", rdata_file, "\n")
    if (cleanup) {
      cat("  Cleaned up temporary files: YES\n")
    } else {
      cat("  Cleaned up temporary files: NO\n")
    }
    cat("===========================================================\n")
    
    cat("Next step: process_all_stations()\n\n")
  }
  
  # Assign to global
  assign("station_list", station_list, envir = .GlobalEnv)
  assign("station_inventory", station_inventory, envir = .GlobalEnv)
  
  invisible(station_inventory$ID)
}
