#' Select High-Quality Weather Stations
#'
#' Filters and selects weather stations based on data quality criteria.
#' This function applies filters for record length, temporal coverage, and
#' selects the best stations for spatial analysis.
#'
#' @param n Number of stations to select (default = 50)
#' @param min_years Minimum record length in years (default = 50)
#' @param min_last_year Stations must have data through at least this year (default = 2020)
#'
#' @return Data frame with selected stations, invisibly. Updates \code{my.inventory}
#'   in the global environment with the filtered selection.
#'
#' @details
#' Quality filters applied:
#' \itemize{
#'   \item Record length >= \code{min_years}
#'   \item Data extends through at least \code{min_last_year}
#'   \item Stations ranked by total record length
#' }
#'
#' The function prioritizes stations with:
#' \itemize{
#'   \item Long, continuous records
#'   \item Recent data availability
#'   \item Good spatial coverage
#' }
#'
#' Approximately 50 stations are recommended for robust heat maps using kriging.
#' Fewer stations may result in poor interpolation; more stations increase
#' download time without substantial improvement.
#'
#' @section Side Effects:
#' Updates the global variable \code{my.inventory} with selected stations.
#' Saves the selection to \code{Data/selected_inventory_[STATE].csv}.
#'
#' @examples
#' \dontrun{
#' # After initialize_project()
#' select_stations(n = 50)
#'
#' # Stricter quality criteria
#' select_stations(n = 30, min_years = 70, min_last_year = 2022)
#'
#' # Capture return value
#' selected <- select_stations(n = 40)
#' summary(selected$RECORD_LENGTH)
#' }
#'
#' @seealso
#' \code{\link{initialize_project}} must be run first
#' \code{\link{download_stations}} to fetch the selected stations
#'
#' @export
select_stations <- function(n = 50, min_years = 50, min_last_year = 2020) {
  
  # Check required variables
  if (!exists("my.inventory", envir = .GlobalEnv)) {
    stop("Run initialize_project() first! Variable 'my.inventory' not found.")
  }
  if (!exists("my.state", envir = .GlobalEnv)) {
    stop("Run initialize_project() first! Variable 'my.state' not found.")
  }
  if (!exists("datafolder", envir = .GlobalEnv)) {
    stop("Run initialize_project() first! Variable 'datafolder' not found.")
  }
  
  my.inventory <- get("my.inventory", envir = .GlobalEnv)
  my.state <- get("my.state", envir = .GlobalEnv)
  datafolder <- get("datafolder", envir = .GlobalEnv)
  
  cat("===========================================================\n")
  cat("  Selecting Stations for Analysis v0.7.0\n")
  cat("===========================================================\n")
  
  cat("Quality filters:\n")
  cat("  Minimum record length:", min_years, "years\n")
  cat("  Must have data through:", min_last_year, "\n")
  cat("  Target number of stations:", n, "\n\n")
  
  # Filter for quality
  filtered <- my.inventory %>%
    dplyr::filter(
      RECORD_LENGTH >= min_years,
      LASTYEAR >= min_last_year
    ) %>%
    dplyr::arrange(desc(RECORD_LENGTH), FIRSTYEAR)
  
  cat("Stations meeting quality criteria:", nrow(filtered), "\n")
  
  # Select top N
  if (nrow(filtered) > n) {
    selected <- filtered[1:n, ]
    cat("Selected top", n, "stations by record length\n")
  } else {
    selected <- filtered
    cat("Using all", nrow(filtered), "available stations\n")
    if (nrow(filtered) < n) {
      warning("Fewer stations available than requested. Consider lowering min_years.")
    }
  }
  
  cat("===========================================================\n")
  cat("Selected Station Summary:\n")
  cat("===========================================================\n")
  cat("  Number of stations:", nrow(selected), "\n")
  cat("  Oldest station start:", min(selected$FIRSTYEAR), "\n")
  cat("  Newest station start:", max(selected$FIRSTYEAR), "\n")
  cat("  Average record length:", round(mean(selected$RECORD_LENGTH), 1), "years\n")
  cat("  Median record length:", median(selected$RECORD_LENGTH), "years\n")
  cat("===========================================================\n")
  
  # Save selected inventory
  write.csv(selected, 
            paste0(datafolder, "selected_inventory_", my.state, ".csv"),
            row.names = FALSE)
  
  # Update global environment
  assign("my.inventory", selected, envir = .GlobalEnv)
  
  cat("[OK] Updated my.inventory with", nrow(selected), "selected stations\n")
  cat("[OK] Saved to:", paste0(datafolder, "selected_inventory_", my.state, ".csv\n\n"))
  
  cat("Next step: download_stations()\n\n")
  
  invisible(selected)
}


#' Download Weather Station Data from NOAA
#'
#' Downloads daily weather data for selected stations from the NOAA GHCN-Daily
#' repository. Data is saved in both compressed (.csv.gz) and uncompressed (.csv)
#' formats during download, then optionally cleaned up after saving to RData.
#'
#' @param cleanup Logical. Remove .gz and .csv files after saving to RData
#'   (default = TRUE). This saves disk space but requires re-download if you
#'   need the raw files again.
#' @param verbose Logical. Show progress messages (default = TRUE)
#'
#' @return Invisibly returns character vector of successfully downloaded station IDs.
#'   Creates files in the Data/ folder.
#'
#' @details
#' Download process:
#' \enumerate{
#'   \item Fetches compressed data (.csv.gz) from NOAA
#'   \item Decompresses to .csv format
#'   \item Validates data structure
#'   \item Saves inventory of successful downloads
#' }
#'
#' The function includes a 0.5 second delay between downloads to be respectful
#' of NOAA's servers. For 50 stations, expect 10-30 minutes depending on your
#' connection speed.
#'
#' Data includes:
#' \itemize{
#'   \item TMAX - Daily maximum temperature
#'   \item TMIN - Daily minimum temperature
#'   \item PRCP - Daily precipitation
#'   \item Plus other elements (SNOW, SNWD, etc.)
#' }
#'
#' @section Files Created:
#' \itemize{
#'   \item \code{[STATION_ID].csv.gz} - Compressed data (temporary if cleanup=TRUE)
#'   \item \code{[STATION_ID].csv} - Uncompressed data (temporary if cleanup=TRUE)
#'   \item \code{downloaded_inventory.csv} - List of successful downloads
#' }
#'
#' @section Error Handling:
#' If individual station downloads fail, the function continues with remaining
#' stations and reports failures at the end. Check the summary for failed stations.
#'
#' @examples
#' \dontrun{
#' # Standard download with cleanup
#' download_stations()
#'
#' # Keep raw CSV files
#' download_stations(cleanup = FALSE)
#'
#' # Silent download
#' download_stations(verbose = FALSE)
#'
#' # Capture list of downloaded stations
#' stations <- download_stations()
#' }
#'
#' @seealso
#' \code{\link{select_stations}} must be run first
#' \code{\link{load_and_save_stations}} to process the downloaded data
#'
#' @export
download_stations <- function(cleanup = TRUE, verbose = TRUE) {
  
  if (!exists("my.inventory", envir = .GlobalEnv)) {
    stop("Run initialize_project() and select_stations() first!")
  }
  if (!exists("datafolder", envir = .GlobalEnv)) {
    stop("Run initialize_project() first! Variable 'datafolder' not found.")
  }
  
  my.inventory <- get("my.inventory", envir = .GlobalEnv)
  datafolder <- get("datafolder", envir = .GlobalEnv)
  
  col_names <- c("ID", "DATE", "ELEMENT", "VALUE", 
                 "M-FLAG", "Q-FLAG", "S-FLAG", "OBS-TIME")
  
  n_stations <- nrow(my.inventory)
  success_count <- 0
  failed_stations <- character(0)
  
  if (verbose) {
    cat("===========================================================\n")
    cat("  Downloading Weather Station Data\n")
    cat("===========================================================\n")
    cat("Stations to download:", n_stations, "\n")
    cat("This may take 10-30 minutes depending on connection...\n\n")
  }
  
  start_time <- Sys.time()
  
  for (i in 1:n_stations) {
    
    station_id <- my.inventory$ID[i]
    
    tryCatch({
      url <- paste0("https://www.ncei.noaa.gov/pub/data/ghcn/daily/by_station/", 
                    station_id, ".csv.gz")
      
      gz_file <- paste0(datafolder, station_id, ".csv.gz")
      csv_file <- paste0(datafolder, station_id, ".csv")
      
      if (verbose) {
        cat(sprintf("[%d/%d] %s ... ", i, n_stations, station_id))
      }
      
      # Download compressed file
      download.file(url, gz_file, quiet = !verbose, mode = "wb")
      
      # Read and save as CSV
      station_data <- read.csv(gz_file, header = FALSE, stringsAsFactors = FALSE)
      names(station_data) <- col_names
      write.csv(station_data, csv_file, row.names = FALSE)
      
      success_count <- success_count + 1
      
      if (verbose) {
        cat(sprintf("OK (%s records)\n", format(nrow(station_data), big.mark = ",")))
      }
      
      Sys.sleep(0.5)  # Be nice to NOAA servers
      
    }, error = function(e) {
      failed_stations <<- c(failed_stations, station_id)
      if (verbose) {
        cat("FAILED:", conditionMessage(e), "\n")
      }
    })
  }
  
  elapsed <- difftime(Sys.time(), start_time, units = "mins")
  
  if (verbose) {
    cat("===========================================================\n")
    cat("Download Summary:\n")
    cat("===========================================================\n")
    cat("  Successfully downloaded:", success_count, "/", n_stations, "\n")
    cat("  Time elapsed:", round(elapsed, 1), "minutes\n")
    
    if (length(failed_stations) > 0) {
      cat("  Failed stations:", length(failed_stations), "\n")
      cat("  ", paste(failed_stations, collapse = ", "), "\n")
    }
    cat("===========================================================\n")
  }
  
  # Save successful inventory
  successful_inventory <- my.inventory[!my.inventory$ID %in% failed_stations, ]
  write.csv(successful_inventory, 
            paste0(datafolder, "downloaded_inventory.csv"), 
            row.names = FALSE)
  
  if (verbose) {
    cat("[OK] Saved inventory of downloaded stations\n\n")
    cat("Next step: load_and_save_stations()\n\n")
  }
  
  invisible(successful_inventory$ID)
}
