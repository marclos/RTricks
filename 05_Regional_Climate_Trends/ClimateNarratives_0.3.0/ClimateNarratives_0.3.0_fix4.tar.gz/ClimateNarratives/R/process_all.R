#' Process All Stations for Spatial Analysis
#'
#' Loops through all loaded stations, cleans data, calculates normals,
#' anomalies, and trend statistics. Returns a data frame with one row per
#' station containing annual and seasonal trend estimates suitable for mapping.
#'
#' @param verbose Logical. Show progress messages (default TRUE).
#'
#' @return Data frame with one row per station and columns for station
#'   metadata (ID, LATITUDE, LONGITUDE, ELEVATION, NAME) plus trend
#'   variables: annual_trend_TMAX, annual_trend_TMIN, annual_trend_PRCP,
#'   and seasonal variants (winter_, spring_, summer_, fall_).
#'
#' @details
#' For each station the function:
#' \enumerate{
#'   \item Fixes dates and value units
#'   \item Calculates monthly values
#'   \item Calculates climate normals (with fallback periods)
#'   \item Calculates anomalies
#'   \item Fits linear trends per month
#'   \item Aggregates to annual and seasonal trend estimates
#' }
#'
#' Stations that lack adequate data for normals are skipped with a warning.
#'
#' @examples
#' \dontrun{
#' trends <- process_all_stations()
#' summary(trends$annual_trend_TMAX)
#' }
#'
#' @seealso \code{\link{create_spatial_objects}} for converting results to
#'   spatial format
#'
#' @export
process_all_stations <- function(verbose = TRUE) {

  if (!exists("station_list", envir = .GlobalEnv)) {
    stop("Run load_stations() or load_and_save_stations() first!")
  }

  station_list <- get("station_list", envir = .GlobalEnv)

  # Get station metadata for coordinates
  inv <- NULL
  if (exists("station_inventory", envir = .GlobalEnv)) {
    inv <- get("station_inventory", envir = .GlobalEnv)
  } else if (exists("my.inventory", envir = .GlobalEnv)) {
    inv <- get("my.inventory", envir = .GlobalEnv)
  }

  if (verbose) {
    cat("===========================================================\n")
    cat("  Processing Stations for Spatial Analysis\n")
    cat("===========================================================\n")
    cat("Stations to process:", length(station_list), "\n\n")
  }

  results_list <- list()
  success <- 0
  skipped <- 0

  for (i in seq_along(station_list)) {
    station_id <- names(station_list)[i]
    station_data <- station_list[[station_id]]

    if (verbose) cat(sprintf("[%d/%d] %s ... ", i, length(station_list), station_id))

    tryCatch({
      # Clean dates and values
      station_data <- fixDates.fun(station_data)
      station_data <- fixValues.fun(station_data)

      # Monthly aggregation
      monthly <- MonthlyValues.fun(station_data)

      # Normals (with fallback cascade)
      normals <- MonthlyNormals.fun(station_data, station_id = station_id)
      if (is.null(normals)) {
        skipped <- skipped + 1
        if (verbose) cat("SKIPPED (no normals)\n")
        next
      }

      # Anomalies
      anomalies <- MonthlyAnomalies.fun(monthly, normals, station_id = station_id)
      if (is.null(anomalies)) {
        skipped <- skipped + 1
        if (verbose) cat("SKIPPED (no anomalies)\n")
        next
      }

      # Monthly trends
      trends <- monthlyTrend.fun(anomalies)
      if (nrow(trends) == 0) {
        skipped <- skipped + 1
        if (verbose) cat("SKIPPED (no trends)\n")
        next
      }

      # ---- Aggregate to annual & seasonal ----
      row <- data.frame(ID = station_id, stringsAsFactors = FALSE)

      for (element in c("TMAX", "TMIN", "PRCP")) {
        elem_trends <- subset(trends, ELEMENT == element)
        if (nrow(elem_trends) == 0) next

        # Annual: mean of all 12 monthly slopes, scaled to per-century
        annual_slope <- mean(elem_trends$Estimate, na.rm = TRUE) * 100
        row[[paste0("annual_trend_", element)]] <- annual_slope

        # Seasonal: mean of seasonal months, scaled to per-century
        winter_months <- c(12, 1, 2)
        spring_months <- c(3, 4, 5)
        summer_months <- c(6, 7, 8)
        fall_months   <- c(9, 10, 11)

        w <- subset(elem_trends, MONTH %in% winter_months)
        s <- subset(elem_trends, MONTH %in% spring_months)
        u <- subset(elem_trends, MONTH %in% summer_months)
        f <- subset(elem_trends, MONTH %in% fall_months)

        if (nrow(w) > 0) row[[paste0("winter_trend_", element)]] <- mean(w$Estimate, na.rm = TRUE) * 100
        if (nrow(s) > 0) row[[paste0("spring_trend_", element)]] <- mean(s$Estimate, na.rm = TRUE) * 100
        if (nrow(u) > 0) row[[paste0("summer_trend_", element)]] <- mean(u$Estimate, na.rm = TRUE) * 100
        if (nrow(f) > 0) row[[paste0("fall_trend_", element)]]   <- mean(f$Estimate, na.rm = TRUE) * 100
      }

      # Add coordinates from inventory
      if (!is.null(inv) && station_id %in% inv$ID) {
        meta <- inv[inv$ID == station_id, ]
        row$LATITUDE  <- meta$LATITUDE[1]
        row$LONGITUDE <- meta$LONGITUDE[1]
        if ("ELEVATION" %in% names(meta)) row$ELEVATION <- meta$ELEVATION[1]
        if ("NAME" %in% names(meta)) row$NAME <- meta$NAME[1]
      }

      results_list[[station_id]] <- row
      success <- success + 1
      if (verbose) cat("OK\n")

    }, error = function(e) {
      skipped <<- skipped + 1
      if (verbose) cat("ERROR:", conditionMessage(e), "\n")
    })
  }

  # Combine all rows
  if (length(results_list) == 0) {
    stop("No stations were successfully processed.")
  }

  # Use rbind with fill to handle possible missing columns
  all_names <- unique(unlist(lapply(results_list, names)))
  results <- do.call(rbind, lapply(results_list, function(r) {
    missing <- setdiff(all_names, names(r))
    for (m in missing) r[[m]] <- NA
    r[all_names]
  }))
  rownames(results) <- NULL

  if (verbose) {
    cat("\n===========================================================\n")
    cat("Processing Summary:\n")
    cat("===========================================================\n")
    cat("  Successfully processed:", success, "\n")
    cat("  Skipped:", skipped, "\n")
    if ("annual_trend_TMAX" %in% names(results)) {
      cat("  Mean annual TMAX trend:",
          round(mean(results$annual_trend_TMAX, na.rm = TRUE), 2), "deg C/century\n")
    }
    if ("annual_trend_TMIN" %in% names(results)) {
      cat("  Mean annual TMIN trend:",
          round(mean(results$annual_trend_TMIN, na.rm = TRUE), 2), "deg C/century\n")
    }
    cat("===========================================================\n\n")
    cat("Next step: create_spatial_objects(trends)\n\n")
  }

  return(results)
}
