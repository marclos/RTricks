#' Create Spatial Objects from Trend Data
#'
#' Converts the trends data frame from \code{\link{process_all_stations}} into
#' spatial formats for mapping.
#'
#' @param trends Data frame from \code{\link{process_all_stations}} with
#'   LATITUDE and LONGITUDE columns.
#'
#' @return Invisibly returns a list with trends_sf and trends_sp.
#'   Also assigns them to the global environment for convenience.
#'
#' @examples
#' \dontrun{
#' trends <- process_all_stations()
#' create_spatial_objects(trends)
#' # trends_sf and trends_sp now available
#' }
#'
#' @export
create_spatial_objects <- function(trends) {

  # Remove rows with missing coordinates
  trends <- trends[!is.na(trends$LATITUDE) & !is.na(trends$LONGITUDE), ]

  if (nrow(trends) == 0) {
    stop("No valid coordinates found in trends data. ",
         "Did initialize_project() run before downloading?")
  }

  # Create sf object (Simple Features - modern approach)
  trends_sf <- sf::st_as_sf(
    trends,
    coords = c("LONGITUDE", "LATITUDE"),
    crs = 4326,
    remove = FALSE
  )

  # Create sp object (needed for gstat kriging)
  coords <- trends[, c("LONGITUDE", "LATITUDE")]
  trends_sp <- sp::SpatialPointsDataFrame(
    coords = coords,
    data = trends,
    proj4string = sp::CRS("+proj=longlat +datum=WGS84")
  )

  assign("trends_sf", trends_sf, envir = .GlobalEnv)
  assign("trends_sp", trends_sp, envir = .GlobalEnv)

  cat("[OK] Created spatial objects:\n")
  cat("  - trends_sf (Simple Features)\n")
  cat("  - trends_sp (Spatial Points)\n")
  cat("  Stations with valid coordinates:", nrow(trends), "\n\n")
  cat("Next step: create_heatmap(trends_sp, 'annual_trend_TMAX', ...)\n\n")

  invisible(list(trends_sf = trends_sf, trends_sp = trends_sp))
}


#' Create Interpolated Heat Map
#'
#' Uses ordinary kriging to interpolate station-level trends onto a
#' regular grid and plots the result over a state boundary map.
#'
#' @param spatial_data A SpatialPointsDataFrame (e.g., \code{trends_sp}).
#' @param trend_var Character string naming the column to map
#'   (e.g., \code{"annual_trend_TMAX"}).
#' @param title Plot title.
#' @param subtitle Plot subtitle (optional).
#' @param state Two-letter state abbreviation for the boundary overlay.
#'   Defaults to the global \code{my.state}.
#' @param colors Character. Either \code{"temp"} (blue-white-red diverging,
#'   default) or \code{"precip"} (brown-white-green diverging).
#' @param resolution Numeric. Grid cell size in degrees (smaller = finer).
#'   Default 0.1.
#'
#' @return A ggplot2 object that can be printed or saved with
#'   \code{ggsave()}.
#'
#' @details
#' The function fits an automatic variogram model and performs ordinary
#' kriging interpolation. The result is clipped to the state boundary.
#'
#' Requires the \pkg{maps} and \pkg{mapdata} packages to be installed
#' (for state boundary data accessed via \code{ggplot2::map_data}).
#'
#' @examples
#' \dontrun{
#' map <- create_heatmap(trends_sp, "annual_trend_TMAX",
#'          "CA - Temperature Trend", state = "CA")
#' print(map)
#' ggsave("my_map.png", map, width = 10, height = 8, dpi = 300)
#' }
#'
#' @export
create_heatmap <- function(spatial_data,
                           trend_var,
                           title = "",
                           subtitle = "",
                           state = NULL,
                           colors = "temp",
                           resolution = 0.1) {

  # ---- validate inputs ----
  if (!inherits(spatial_data, "SpatialPointsDataFrame")) {
    stop("spatial_data must be a SpatialPointsDataFrame. ",
         "Run create_spatial_objects(trends) first.")
  }

  if (!trend_var %in% names(spatial_data@data)) {
    stop("Variable '", trend_var, "' not found in spatial_data. ",
         "Available: ", paste(names(spatial_data@data), collapse = ", "))
  }

  # Check for maps package
  if (!requireNamespace("maps", quietly = TRUE)) {
    stop("Package 'maps' is required for state boundaries. ",
         "Install with: install.packages('maps')")
  }

  # State lookup (abbreviation -> full name for maps package)
  state_lookup <- c(
    AL = "alabama", AK = "alaska", AZ = "arizona", AR = "arkansas",
    CA = "california", CO = "colorado", CT = "connecticut", DE = "delaware",
    FL = "florida", GA = "georgia", HI = "hawaii", ID = "idaho",
    IL = "illinois", IN = "indiana", IA = "iowa", KS = "kansas",
    KY = "kentucky", LA = "louisiana", ME = "maine", MD = "maryland",
    MA = "massachusetts", MI = "michigan", MN = "minnesota", MS = "mississippi",
    MO = "missouri", MT = "montana", NE = "nebraska", NV = "nevada",
    NH = "new hampshire", NJ = "new jersey", NM = "new mexico", NY = "new york",
    NC = "north carolina", ND = "north dakota", OH = "ohio", OK = "oklahoma",
    OR = "oregon", PA = "pennsylvania", RI = "rhode island", SC = "south carolina",
    SD = "south dakota", TN = "tennessee", TX = "texas", UT = "utah",
    VT = "vermont", VA = "virginia", WA = "washington", WV = "west virginia",
    WI = "wisconsin", WY = "wyoming"
  )

  if (is.null(state)) {
    if (exists("my.state", envir = .GlobalEnv)) {
      state <- get("my.state", envir = .GlobalEnv)
    } else {
      stop("Provide state= argument or run initialize_project() first.")
    }
  }

  state_name <- state_lookup[toupper(state)]
  if (is.na(state_name)) {
    warning("State '", state, "' not found in lookup. Skipping boundary overlay.")
    state_name <- NULL
  }

  # ---- remove NAs in trend variable ----
  valid_idx <- !is.na(spatial_data@data[[trend_var]])
  if (sum(valid_idx) < 4) {
    stop("Need at least 4 stations with non-NA values for kriging. ",
         "Only ", sum(valid_idx), " available for '", trend_var, "'.")
  }
  sp_clean <- spatial_data[valid_idx, ]

  # ---- create interpolation grid ----
  bbox <- sp::bbox(sp_clean)
  # Expand bounding box slightly
  x_range <- seq(bbox[1, 1] - 0.5, bbox[1, 2] + 0.5, by = resolution)
  y_range <- seq(bbox[2, 1] - 0.5, bbox[2, 2] + 0.5, by = resolution)
  grid <- expand.grid(LONGITUDE = x_range, LATITUDE = y_range)
  sp::coordinates(grid) <- ~ LONGITUDE + LATITUDE
  sp::proj4string(grid) <- sp::CRS("+proj=longlat +datum=WGS84")
  sp::gridded(grid) <- TRUE

  # ---- fit variogram and krige ----
  formula <- as.formula(paste(trend_var, "~ 1"))

  vario <- tryCatch(
    gstat::variogram(formula, sp_clean),
    error = function(e) NULL
  )

  if (is.null(vario) || nrow(vario) == 0) {
    warning("Could not compute variogram for '", trend_var,
            "'. Trying simple model.")
    # Fallback: use a simple spherical model with reasonable defaults
    vario_model <- gstat::vgm(psill = var(sp_clean@data[[trend_var]], na.rm = TRUE),
                               model = "Sph",
                               range = max(diff(range(sp::coordinates(sp_clean)[,1])),
                                           diff(range(sp::coordinates(sp_clean)[,2]))) / 3,
                               nugget = 0)
  } else {
    vario_model <- tryCatch(
      gstat::fit.variogram(vario, gstat::vgm("Sph")),
      error = function(e) {
        tryCatch(
          gstat::fit.variogram(vario, gstat::vgm("Exp")),
          error = function(e2) {
            # Last resort
            gstat::vgm(psill = var(sp_clean@data[[trend_var]], na.rm = TRUE),
                       model = "Sph",
                       range = max(vario$dist) / 3,
                       nugget = 0)
          }
        )
      }
    )
  }

  kriged <- tryCatch(
    gstat::krige(formula, sp_clean, grid, model = vario_model, debug.level = 0),
    error = function(e) {
      stop("Kriging failed: ", conditionMessage(e),
           "\nTry increasing resolution (e.g., resolution = 0.2) ",
           "or check that stations have good spatial coverage.")
    }
  )

  # Convert kriged result to data frame
  kriged_df <- as.data.frame(kriged)
  names(kriged_df)[1:3] <- c("LONGITUDE", "LATITUDE", "predicted")

  # ---- get state boundary ----
  state_border <- NULL
  if (!is.null(state_name)) {
    state_border <- tryCatch(
      ggplot2::map_data("state", region = state_name),
      error = function(e) NULL
    )
  }

  # Clip kriged surface to state boundary if available
  if (!is.null(state_border)) {
    x_min <- min(state_border$long) - 0.1
    x_max <- max(state_border$long) + 0.1
    y_min <- min(state_border$lat) - 0.1
    y_max <- max(state_border$lat) + 0.1
    kriged_df <- kriged_df[
      kriged_df$LONGITUDE >= x_min & kriged_df$LONGITUDE <= x_max &
      kriged_df$LATITUDE  >= y_min & kriged_df$LATITUDE  <= y_max, ]
  }

  # ---- color palette ----
  val_range <- range(kriged_df$predicted, na.rm = TRUE)
  if (colors == "precip") {
    low_col  <- "#8B4513"   # brown
    mid_col  <- "white"
    high_col <- "#006400"   # dark green
  } else {
    low_col  <- "blue"
    mid_col  <- "white"
    high_col <- "red"
  }

  # ---- build the plot ----
  p <- ggplot2::ggplot() +
    ggplot2::geom_tile(
      data = kriged_df,
      ggplot2::aes(x = LONGITUDE, y = LATITUDE, fill = predicted)
    ) +
    ggplot2::scale_fill_gradient2(
      low = low_col, mid = mid_col, high = high_col,
      midpoint = 0,
      name = trend_var
    )

  # Add state boundary
  if (!is.null(state_border)) {
    p <- p +
      ggplot2::geom_polygon(
        data = state_border,
        ggplot2::aes(x = long, y = lat, group = group),
        fill = NA, color = "black", linewidth = 0.5
      ) +
      ggplot2::coord_fixed(
        xlim = range(state_border$long) + c(-0.1, 0.1),
        ylim = range(state_border$lat)  + c(-0.1, 0.1),
        ratio = 1.3
      )
  } else {
    p <- p + ggplot2::coord_fixed(ratio = 1.3)
  }

  # Add station points
  station_df <- as.data.frame(sp_clean)
  p <- p +
    ggplot2::geom_point(
      data = station_df,
      ggplot2::aes(x = LONGITUDE, y = LATITUDE),
      size = 1, color = "black", shape = 16
    )

  # Theme and labels
  p <- p +
    ggplot2::labs(title = title, subtitle = subtitle) +
    ggplot2::theme_minimal() +
    ggplot2::theme(
      axis.title = ggplot2::element_blank(),
      panel.grid = ggplot2::element_line(color = "grey90")
    )

  return(p)
}
