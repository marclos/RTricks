# ClimateNarratives

An R package for analyzing and visualizing regional climate trends using NOAA GHCN-Daily data. Designed for teaching R programming through climate science.

## Installation

### Step 1: Check dependencies (do this first!)

```r
source("ClimateNarratives/R/ClimateNarratives-package.R")
check_dependencies()
```

### Step 2: Install the package

```r
# From local source:
source("ClimateNarratives/install_package.R")

# Or from GitHub:
devtools::install_github("marcloshuertos/ClimateNarratives")
```

## Quick Start

```r
library(ClimateNarratives)
initialize_project("CA")       # creates ~/ClimateNarratives_CA/
select_stations(n = 50)
download_stations()             # 10-30 min
load_and_save_stations()

trends <- process_all_stations()
create_spatial_objects(trends)
map <- create_heatmap(trends_sp, "annual_trend_TMAX",
       "CA Annual TMAX Trend", state = "CA")
ggsave(paste0(figuresfolder, "TMAX_CA.png"), map,
       width = 10, height = 8, dpi = 300)
```

## Documentation

- `ClimateNarratives_Student_Workflow.md` — Step-by-step student guide
- `ClimateNarratives_Teacher_Guide.md` — Deployment, troubleshooting, assessment
- `ClimateNarratives_Package_Reference.md` — Complete function reference
- `example_workflow.R` — Full working script (change one line and run)
- `?ClimateNarratives` — In-R help after installation

## Version 0.3.0

- Dependency checker with clear pass/fail reporting
- Auto-generated project paths (no student editing needed)
- Robust climate normals with fallback periods for states with sparse data
- Graceful handling of stations with insufficient data

## License

GPL-3
