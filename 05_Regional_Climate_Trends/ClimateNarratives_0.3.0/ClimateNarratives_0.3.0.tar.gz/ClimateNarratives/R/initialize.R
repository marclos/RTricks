#' Initialize Climate Narratives Project
#'
#' This is the main setup function that configures your entire project workspace.
#' It creates the directory structure, downloads station inventory, and sets up
#' global variables needed for all subsequent analysis.
#'
#' @param state Two-letter state abbreviation (e.g., "CA", "NV", "TX")
#' @param path Base path for the project. If omitted, a folder called
#'   \code{ClimateNarratives_XX} (where XX is the state code) is created in
#'   your home directory. Can also be an explicit relative or absolute path.
#'
#' @return Invisibly returns a list containing:
#' \itemize{
#'   \item state - The state abbreviation
#'   \item paths - Named list of project directories (root, data, output, figures)
#'   \item inventory - Data frame of available weather stations
#'   \item datafolder - Path to Data folder (with trailing slash)
#'   \item figuresfolder - Path to Figures folder (with trailing slash)
#' }
#'
#' @details
#' This function creates three subdirectories:
#' \itemize{
#'   \item Data/ - For downloaded weather data and processed files
#'   \item Output/ - For analysis results and tables
#'   \item Figures/ - For plots and heat maps
#' }
#'
#' The following variables are created in your global environment:
#' \itemize{
#'   \item \code{my.state} - Your state abbreviation
#'   \item \code{my.inventory} - Data frame of available stations
#'   \item \code{datafolder} - Path to Data/ (for reading/writing data)
#'   \item \code{figuresfolder} - Path to Figures/ (for saving plots)
#' }
#'
#' After setup, your working directory is changed to the project root so that
#' \code{ggsave("mymap.png", ...)} saves to the right place without editing paths.
#'
#' @examples
#' \dontrun{
#' # Simplest: auto-creates ~/ClimateNarratives_CA/
#' initialize_project("CA")
#'
#' # Explicit path
#' initialize_project("CA", path = "~/Documents/ClimateProject")
#'
#' # Capture return values
#' project <- initialize_project("TX")
#' }
#'
#' @seealso
#' \code{\link{select_stations}} to choose high-quality stations
#' \code{\link{download_stations}} to fetch data from NOAA
#'
#' @export
initialize_project <- function(state, path = NULL) {

  cat("\n")
  cat("===========================================================\n")
  cat("  Climate Narratives Project Setup v0.3.0\n")
  cat("===========================================================\n")

  # Validate state
  if (missing(state) || is.null(state)) {
    stop("Please provide a state abbreviation (e.g., 'CA', 'TX')")
  }

  if (nchar(state) != 2) {
    stop("State must be a 2-letter abbreviation (e.g., 'CA', 'NV', 'TX')")
  }
  state <- toupper(state)

  # ---- Auto-generate path from state if not supplied ----
  if (is.null(path)) {
    path <- file.path(path.expand("~"),
                      paste0("ClimateNarratives_", state))
    cat("  Using default project folder:\n")
    cat("    ", path, "\n")
  }

  cat("  State:", state, "\n")
  cat("  Path: ", path, "\n")
  cat("===========================================================\n\n")

  # Expand path
  path <- normalizePath(path, mustWork = FALSE)

  # Create root if needed
  if (!dir.exists(path)) {
    dir.create(path, recursive = TRUE)
    cat("  [OK] Created project folder:", path, "\n")
  }

  # Create directory structure
  dirs <- list(
    root    = path,
    data    = file.path(path, "Data"),
    output  = file.path(path, "Output"),
    figures = file.path(path, "Figures")
  )

  cat("Creating directories...\n")
  for (dir_name in names(dirs)) {
    if (dir_name == "root") next
    if (!dir.exists(dirs[[dir_name]])) {
      dir.create(dirs[[dir_name]], recursive = TRUE)
      cat("  [OK] Created:", dirs[[dir_name]], "\n")
    } else {
      cat("  [OK] Exists:", dirs[[dir_name]], "\n")
    }
  }

  # ---- Set working directory to project root ----
  old_wd <- getwd()
  setwd(path)
  cat("\n[OK] Set working directory to:", path, "\n")

  # Use RELATIVE paths so ggsave("Figures/mymap.png") just works
  datafolder    <- "Data/"
  figuresfolder <- "Figures/"

  assign("datafolder",    datafolder,    envir = .GlobalEnv)
  assign("figuresfolder", figuresfolder, envir = .GlobalEnv)
  # Also store the absolute root in case anyone needs it
  assign("projectfolder", paste0(path, "/"), envir = .GlobalEnv)

  cat("[OK] Set folder variables:\n")
  cat("     datafolder    =", datafolder, "\n")
  cat("     figuresfolder =", figuresfolder, "\n")
  cat("     (working directory is now the project root)\n")

  # Download station inventory
  inventory_file <- file.path(dirs$data, "stations.active.oldest.csv")

  if (!file.exists(inventory_file)) {
    cat("\nDownloading station inventory from NOAA...\n")
    tryCatch({
      inventory <- download_station_inventory()
      write.csv(inventory, inventory_file, row.names = FALSE)
      cat("[OK] Saved station inventory\n")
    }, error = function(e) {
      # Restore working directory on failure
      setwd(old_wd)
      stop("Failed to download inventory: ", e$message,
           "\nCheck your internet connection and try again.")
    })
  } else {
    cat("\n[OK] Station inventory already exists\n")
    inventory <- read.csv(inventory_file, stringsAsFactors = FALSE)
  }

  # Subset for selected state
  my.inventory <- subset(inventory, STATE == state)

  if (nrow(my.inventory) == 0) {
    cat("\nAvailable states:\n")
    print(sort(unique(inventory$STATE)))
    setwd(old_wd)
    stop("No stations found for state: ", state)
  }

  cat("\n[OK] Found", nrow(my.inventory), "potential stations for", state, "\n\n")

  # Store in global environment
  assign("my.state", state, envir = .GlobalEnv)
  assign("my.inventory", my.inventory, envir = .GlobalEnv)

  cat("===========================================================\n")
  cat("  Setup Complete!\n")
  cat("===========================================================\n")
  cat("  Variables created in global environment:\n")
  cat("    * my.state       =", state, "\n")
  cat("    * my.inventory   =", nrow(my.inventory), "potential stations\n")
  cat("    * datafolder     =", datafolder, "\n")
  cat("    * figuresfolder  =", figuresfolder, "\n")
  cat("    * projectfolder  =", paste0(path, "/"), "\n")
  cat("  Working directory:\n")
  cat("    ", getwd(), "\n")
  cat("===========================================================\n")
  cat("  Next step:\n")
  cat("    select_stations(n = 50)\n")
  cat("===========================================================\n\n")

  invisible(list(
    state = state,
    paths = dirs,
    inventory = my.inventory,
    datafolder = datafolder,
    figuresfolder = figuresfolder
  ))
}


#' Set Project Configuration
#'
#' A convenience function to quickly set or change the state and path
#' without re-downloading inventory data.
#'
#' @param state Two-letter state abbreviation
#' @param path Project base path (default: auto-generated from state)
#'
#' @return Invisibly returns the project configuration list
#'
#' @examples
#' \dontrun{
#' # Quick configuration
#' set_config("CA")
#' set_config("CA", "~/ClimateProject")
#' }
#'
#' @export
set_config <- function(state, path = NULL) {
  initialize_project(state, path)
}
