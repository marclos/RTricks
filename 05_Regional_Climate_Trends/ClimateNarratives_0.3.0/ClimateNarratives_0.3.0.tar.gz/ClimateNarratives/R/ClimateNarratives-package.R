#' ClimateNarratives Package
#'
#' Tools for analyzing and visualizing regional climate trends using NOAA GHCN-Daily data.
#'
#' @docType package
#' @name ClimateNarratives
#' @import dplyr tidyr ggplot2 sf sp
#' @importFrom lubridate year month
#' @importFrom gstat variogram fit.variogram krige vgm
#' @importFrom viridis scale_fill_viridis_c
#' @importFrom patchwork plot_annotation
#' @importFrom stats lm coef aggregate median sd cor
#' @importFrom utils read.csv write.csv download.file installed.packages install.packages
#' @importFrom grDevices dev.off png
#' @importFrom graphics abline hist legend lines par points
NULL


#' Check and Install Package Dependencies
#'
#' Checks whether all required packages are installed and offers to install
#' any that are missing. Prints a clear pass/fail report for each package.
#'
#' @param install Logical. If TRUE (default), automatically install missing
#'   packages. If FALSE, just report what's missing.
#' @param quiet Logical. Suppress individual package install messages (default FALSE).
#'
#' @return Invisibly returns a logical: TRUE if all dependencies are satisfied,
#'   FALSE otherwise.
#'
#' @details
#' This function checks for all packages required by ClimateNarratives.
#' Run this BEFORE \code{install.packages()} or \code{devtools::install()} to
#' avoid cryptic installation failures.
#'
#' @examples
#' \dontrun{
#' # Check and install everything
#' check_dependencies()
#'
#' # Just see what's missing without installing
#' check_dependencies(install = FALSE)
#' }
#'
#' @export
check_dependencies <- function(install = TRUE, quiet = FALSE) {

  required <- c(
    # Core tidyverse-adjacent
    "dplyr", "tidyr", "ggplot2", "lubridate",
    # Spatial
    "sp", "sf", "gstat", "raster", "stars",
    # Mapping / visualization
    "viridis", "maps", "mapdata", "patchwork",
    # Build tools (needed for install-from-source)
    "devtools", "roxygen2", "knitr", "rmarkdown"
  )

  cat("\n")
  cat("===========================================================\n")
  cat("  ClimateNarratives Dependency Check\n")
  cat("===========================================================\n\n")

  installed <- rownames(installed.packages())
  status    <- required %in% installed
  missing   <- required[!status]

  # Report each package
  for (i in seq_along(required)) {
    pkg <- required[i]
    if (status[i]) {
      cat("  [OK]   ", pkg, "\n")
    } else {
      cat("  [MISS] ", pkg, "\n")
    }
  }

  cat("\n-----------------------------------------------------------\n")

  if (length(missing) == 0) {
    cat("  All", length(required), "dependencies are installed!\n")
    cat("===========================================================\n\n")
    return(invisible(TRUE))
  }

  cat("  Missing packages:", length(missing), "of", length(required), "\n")
  cat("  ", paste(missing, collapse = ", "), "\n")
  cat("-----------------------------------------------------------\n")

 if (!install) {
    cat("  Run check_dependencies(install = TRUE) to install them.\n")
    cat("===========================================================\n\n")
    return(invisible(FALSE))
  }

  cat("  Installing missing packages now...\n\n")

  failures <- character(0)
  for (pkg in missing) {
    cat("  Installing", pkg, "... ")
    tryCatch({
      install.packages(pkg, quiet = quiet)
      # Verify it actually installed
      if (requireNamespace(pkg, quietly = TRUE)) {
        cat("OK\n")
      } else {
        cat("FAILED (installed but not loadable)\n")
        failures <- c(failures, pkg)
      }
    }, error = function(e) {
      cat("FAILED:", conditionMessage(e), "\n")
      failures <<- c(failures, pkg)
    })
  }

  cat("\n-----------------------------------------------------------\n")
  if (length(failures) == 0) {
    cat("  All dependencies installed successfully!\n")
    cat("  You can now install ClimateNarratives.\n")
    cat("===========================================================\n\n")
    return(invisible(TRUE))
  } else {
    cat("  WARNING: These packages failed to install:\n")
    cat("  ", paste(failures, collapse = ", "), "\n\n")
    cat("  Try installing them manually:\n")
    cat('  install.packages(c("', paste(failures, collapse = '", "'), '"))\n', sep = "")
    cat("  Then re-run check_dependencies()\n")
    cat("===========================================================\n\n")
    return(invisible(FALSE))
  }
}


#' Download Station Inventory from NOAA
#'
#' Internal function to fetch the complete station inventory from NOAA.
#'
#' @return Data frame with station inventory including metadata
#' @keywords internal
#' @noRd
download_station_inventory <- function() {

  cat("Downloading inventory from NOAA (this may take a minute)...\n")

  # Read inventory
  inventory <- read.table(
    "https://www.ncei.noaa.gov/pub/data/ghcn/daily/ghcnd-inventory.txt",
    col.names = c("ID", "LATITUDE", "LONGITUDE", "ELEMENT", "FIRSTYEAR", "LASTYEAR")
  )

  # Subset for TMAX and active stations
  inventory_TMAX <- subset(inventory, ELEMENT == "TMAX" & LASTYEAR >= 2023)

  # Read station metadata
  Stations <- read.fwf(
    "https://www.ncei.noaa.gov/pub/data/ghcn/daily/ghcnd-stations.txt",
    widths = c(11, -1, 8, -1, 9, -1, 6, -1, 2, -1, 30, -1, 3, -1, 3, -1, 5),
    col.names = c("ID", "LATITUDE", "LONGITUDE", "ELEVATION", "STATE",
                  "NAME", "GSN_FLAG", "HCN_CRN_FLAG", "WMO_ID"),
    fill = TRUE,
    strip.white = TRUE
  )

  # Read state names
  States <- read.fwf(
    "https://www.ncei.noaa.gov/pub/data/ghcn/daily/ghcnd-states.txt",
    widths = c(2, -1, 46),
    col.names = c("STATE", "STATE_NAME"),
    fill = TRUE,
    strip.white = TRUE
  )

  # Get station metadata with state names
  StationMeta <- subset(Stations, select = c("ID", "LATITUDE", "LONGITUDE",
                                              "ELEVATION", "STATE", "NAME"))
  StationMeta <- merge(StationMeta, States, by = "STATE")

  # Merge with inventory to add date ranges
  inventory_merged <- merge(
    subset(inventory_TMAX, select = c("ID", "FIRSTYEAR", "LASTYEAR")),
    StationMeta,
    by = "ID"
  )

  # Remove blank states
  inventory_merged <- subset(inventory_merged, STATE != "" & STATE != " ")

  # Calculate record length
  inventory_merged$RECORD_LENGTH <-
    inventory_merged$LASTYEAR - inventory_merged$FIRSTYEAR + 1

  return(inventory_merged)
}


#' Load Previously Saved Station Data
#'
#' Loads station data from RData file created by \code{\link{load_and_save_stations}}.
#'
#' @param verbose Logical. Show progress messages (default = TRUE)
#'
#' @return Invisibly returns character vector of loaded station IDs
#'
#' @details
#' This function loads the \code{all_stations_raw.RData} file from your Data folder
#' and assigns both the \code{station_list} and individual station data frames
#' to your global environment.
#'
#' @section Requirements:
#' Must have previously run \code{\link{load_and_save_stations}} to create the RData file.
#'
#' @examples
#' \dontrun{
#' # After downloading and saving stations
#' load_stations()
#'
#' # Access individual station data
#' head(USC00045123)  # Example station ID
#' }
#'
#' @seealso \code{\link{load_and_save_stations}} to create the RData file
#'
#' @export
load_stations <- function(verbose = TRUE) {

  if (!exists("datafolder", envir = .GlobalEnv)) {
    stop("Run initialize_project() first! Variable 'datafolder' not found.")
  }

  datafolder <- get("datafolder", envir = .GlobalEnv)
  rdata_file <- paste0(datafolder, "all_stations_raw.RData")

  if (!file.exists(rdata_file)) {
    stop("RData file not found: ", rdata_file, "\n",
         "Run load_and_save_stations() first to create this file.")
  }

  load(rdata_file, envir = .GlobalEnv)

  # Also assign individual stations to global environment
  station_list <- get("station_list", envir = .GlobalEnv)
  for (station_id in names(station_list)) {
    assign(station_id, station_list[[station_id]], envir = .GlobalEnv)
  }

  if (verbose) {
    cat("[OK] Loaded", length(station_list), "stations from", rdata_file, "\n")
  }

  invisible(names(station_list))
}


#' @keywords internal
.onAttach <- function(libname, pkgname) {

 # --------------- lightweight dependency check at load time ---------------
  core_pkgs <- c("dplyr", "tidyr", "ggplot2", "lubridate",
                 "sp", "sf", "gstat", "raster", "stars",
                 "viridis", "maps", "mapdata", "patchwork")
  missing <- core_pkgs[!vapply(core_pkgs, requireNamespace,
                               logical(1), quietly = TRUE)]

  if (length(missing) > 0) {
    packageStartupMessage(
      "\n",
      "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n",
      "  WARNING: Missing required packages!\n",
      "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n",
      "  The following packages are not installed:\n",
      "    ", paste(missing, collapse = ", "), "\n\n",
      "  ClimateNarratives will NOT work until these are installed.\n",
      "  Run this command to fix it:\n\n",
      '    check_dependencies()\n\n',
      "  Or install manually:\n",
      '    install.packages(c("', paste(missing, collapse = '", "'), '"))\n',
      "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n"
    )
  } else {
    packageStartupMessage(
      "===========================================================\n",
      " ClimateNarratives v0.3.0\n",
      "===========================================================\n",
      " Regional Climate Trends Analysis and Visualization\n",
      " Type ?ClimateNarratives for help\n",
      "===========================================================\n",
      "\n",
      " Quick Start:\n",
      "   initialize_project('CA')  # Set up for California\n",
      "   ?initialize_project       # See documentation\n",
      "===========================================================\n"
    )
  }
}
