#' Calculate Monthly Aggregated Values
#' @param station Cleaned station data
#' @return List with TMAX, TMIN, PRCP monthly values
#' @export
MonthlyValues.fun <- function(station) {
  TMAX.monthly <- aggregate(VALUE ~ MONTH + YEAR,
                            data = subset(station, ELEMENT == "TMAX"),
                            mean, na.rm = TRUE)
  names(TMAX.monthly) <- c("MONTH", "YEAR", "TMAX")
  
  TMIN.monthly <- aggregate(VALUE ~ MONTH + YEAR,
                            data = subset(station, ELEMENT == "TMIN"),
                            mean, na.rm = TRUE)
  names(TMIN.monthly) <- c("MONTH", "YEAR", "TMIN")
  
  PRCP.monthly <- aggregate(VALUE ~ MONTH + YEAR,
                            data = subset(station, ELEMENT == "PRCP"),
                            sum, na.rm = TRUE)
  names(PRCP.monthly) <- c("MONTH", "YEAR", "PRCP")
  
  return(list(TMAX = TMAX.monthly, TMIN = TMIN.monthly, PRCP = PRCP.monthly))
}

#' Calculate Climate Normals (1961-1990)
#' @param station Cleaned station data
#' @return List with TMAX, TMIN, PRCP normals
#' @export
MonthlyNormals.fun <- function(station) {
  station.normals <- subset(station, 
                            Ymd >= as.Date("1961-01-01") & 
                              Ymd <= as.Date("1990-12-31"))
  
  if (nrow(station.normals) == 0) {
    warning("No data in 1961-1990 period. Using all available data.")
    station.normals <- station
  }
  
  TMAX.normals <- aggregate(VALUE ~ MONTH,
                            data = subset(station.normals, ELEMENT == "TMAX"),
                            mean, na.rm = TRUE)
  names(TMAX.normals) <- c("MONTH", "NORMALS")
  
  TMIN.normals <- aggregate(VALUE ~ MONTH,
                            data = subset(station.normals, ELEMENT == "TMIN"),
                            mean, na.rm = TRUE)
  names(TMIN.normals) <- c("MONTH", "NORMALS")
  
  PRCP.month.year <- aggregate(VALUE ~ MONTH + YEAR,
                               data = subset(station.normals, ELEMENT == "PRCP"),
                               sum, na.rm = TRUE)
  PRCP.normals <- aggregate(VALUE ~ MONTH, 
                            data = PRCP.month.year, 
                            mean, na.rm = TRUE)
  names(PRCP.normals) <- c("MONTH", "NORMALS")
  
  return(list(TMAX = TMAX.normals, TMIN = TMIN.normals, PRCP = PRCP.normals))
}

#' Calculate Monthly Anomalies
#' @param station.monthly Output from MonthlyValues.fun
#' @param station.normals Output from MonthlyNormals.fun
#' @return List with anomaly data frames
#' @export
MonthlyAnomalies.fun <- function(station.monthly, station.normals) {
  TMAX <- merge(station.monthly$TMAX, station.normals$TMAX, by = "MONTH")
  TMAX$TMAX.a <- TMAX$TMAX - TMAX$NORMALS
  TMAX$Ymd <- as.Date(paste(TMAX$YEAR, TMAX$MONTH, "01", sep = "-"))
  
  TMIN <- merge(station.monthly$TMIN, station.normals$TMIN, by = "MONTH")
  TMIN$TMIN.a <- TMIN$TMIN - TMIN$NORMALS
  TMIN$Ymd <- as.Date(paste(TMIN$YEAR, TMIN$MONTH, "01", sep = "-"))
  
  PRCP <- merge(station.monthly$PRCP, station.normals$PRCP, by = "MONTH")
  PRCP$PRCP.a <- PRCP$PRCP - PRCP$NORMALS
  PRCP$Ymd <- as.Date(paste(PRCP$YEAR, PRCP$MONTH, "01", sep = "-"))
  
  return(list(TMAX = TMAX, TMIN = TMIN, PRCP = PRCP))
}

#' Calculate Monthly Trends
#' @param station.anomalies Output from MonthlyAnomalies.fun
#' @return Data frame with trend statistics
#' @export
monthlyTrend.fun <- function(station.anomalies) {
  results <- data.frame()
  
  for (element in c("TMAX", "TMIN", "PRCP")) {
    data <- station.anomalies[[element]]
    anom_col <- paste0(element, ".a")
    
    for (m in 1:12) {
      month_data <- subset(data, MONTH == m)
      
      if (nrow(month_data) >= 10) {
        formula <- as.formula(paste(anom_col, "~ YEAR"))
        model <- lm(formula, data = month_data)
        s <- summary(model)
        
        results <- rbind(results, data.frame(
          MONTH = m,
          ELEMENT = element,
          Estimate = coef(model)[2],
          Std.Error = s$coefficients[2, 2],
          t.value = s$coefficients[2, 3],
          `Pr(>|t|)` = s$coefficients[2, 4],
          r.squared = s$r.squared,
          check.names = FALSE
        ))
      }
    }
  }
  
  results$Signif <- ""
  results$Signif[results$`Pr(>|t|)` < 0.05] <- "*"
  results$Signif[results$`Pr(>|t|)` < 0.01] <- "**"
  results$Signif[results$`Pr(>|t|)` < 0.001] <- "***"
  
  return(results)
}
