#' Calculate Monthly Aggregated Values with Completeness Filtering
#'
#' Aggregates daily data to monthly values: mean for TMAX/TMIN, sum for PRCP.
#' Months with too few observed days are set to NA to prevent biased estimates,
#' particularly for precipitation totals where missing days cause undercounting.
#'
#' @param station Cleaned station data (must contain Ymd, ELEMENT, VALUE, MONTH, YEAR)
#' @param min_days_temp Minimum number of non-missing days required per month
#'   for temperature elements (TMAX, TMIN). Default 20. Months with fewer
#'   observed days are set to NA.
#' @param min_days_prcp Minimum number of non-missing days required per month
#'   for precipitation. Default 25 (stricter because sum is sensitive to gaps).
#'   Months with fewer observed days are set to NA.
#'
#' @return List with TMAX, TMIN, PRCP monthly data frames. Each contains
#'   MONTH, YEAR, the aggregated value, and n_days (count of non-missing days).
#'
#' @details
#' \strong{Why completeness matters:}
#' For temperature, \code{mean(na.rm=TRUE)} on 15 of 30 days is a somewhat
#' biased estimator but usually acceptable. For precipitation, \code{sum(na.rm=TRUE)}
#' on 15 of 30 days produces roughly HALF the true monthly total, which
#' creates large negative anomalies and biases trend estimates downward.
#'
#' The default thresholds (20 days for temperature, 25 for precipitation)
#' follow common practice in climate data analysis. Setting both to 0
#' reproduces the v0.3.0 behavior (no filtering).
#'
#' @seealso \code{\link{MonthlyNormals.fun}}, \code{\link{coverage.fun}}
#'
#' @export
MonthlyValues.fun <- function(station, min_days_temp = 20, min_days_prcp = 25) {

  # ---- helper: aggregate one element with completeness check ----
  .agg_element <- function(data, element, agg_fun, min_days) {
    elem <- subset(data, ELEMENT == element & !is.na(VALUE))
    if (nrow(elem) == 0) return(data.frame(MONTH = integer(0),
                                            YEAR = integer(0),
                                            VALUE = numeric(0),
                                            n_days = integer(0)))

    # Count non-missing days per month-year
    counts <- aggregate(VALUE ~ MONTH + YEAR, data = elem, FUN = length)
    names(counts)[3] <- "n_days"

    # Aggregate values
    vals <- aggregate(VALUE ~ MONTH + YEAR, data = elem, FUN = agg_fun, na.rm = TRUE)

    result <- merge(vals, counts, by = c("MONTH", "YEAR"))

    # Set incomplete months to NA
    result$VALUE[result$n_days < min_days] <- NA

    return(result)
  }

  TMAX.monthly <- .agg_element(station, "TMAX", mean, min_days_temp)
  names(TMAX.monthly) <- c("MONTH", "YEAR", "TMAX", "n_days")

  TMIN.monthly <- .agg_element(station, "TMIN", mean, min_days_temp)
  names(TMIN.monthly) <- c("MONTH", "YEAR", "TMIN", "n_days")

  PRCP.monthly <- .agg_element(station, "PRCP", sum, min_days_prcp)
  names(PRCP.monthly) <- c("MONTH", "YEAR", "PRCP", "n_days")

  # Drop rows where the value is NA (incomplete months)
  TMAX.monthly <- TMAX.monthly[!is.na(TMAX.monthly$TMAX), ]
  TMIN.monthly <- TMIN.monthly[!is.na(TMIN.monthly$TMIN), ]
  PRCP.monthly <- PRCP.monthly[!is.na(PRCP.monthly$PRCP), ]

  return(list(TMAX = TMAX.monthly, TMIN = TMIN.monthly, PRCP = PRCP.monthly))
}

#' Calculate Climate Normals with Fallback Periods
#'
#' Calculates the 1961-1990 climate normals following WMO convention.
#' If the standard period has insufficient data the function tries a
#' 30-year rolling window and, as a last resort, uses the full record.
#'
#' @param station Cleaned station data (must contain Ymd, ELEMENT, VALUE, MONTH)
#' @param min_months_required Minimum number of distinct months (1-12) that
#'   must be represented in the normals period for each element. Default 12
#'   (all months required).
#' @param min_years_per_month Minimum number of years of data required for
#'   each individual month to be considered reliable. Default 10.
#' @param station_id Optional station ID string used in warning messages
#'   so students can tell WHICH station had problems.
#'
#' @return A list with components TMAX, TMIN, PRCP (data frames with MONTH
#'   and NORMALS columns), plus an attribute \code{"normals_period"} that
#'   records which period was actually used.
#'   Returns NULL if no adequate normals can be calculated.
#'
#' @export
MonthlyNormals.fun <- function(station,
                                min_months_required = 12,
                                min_years_per_month = 10,
                                station_id = "unknown") {

  # ---- helper: try computing normals from a subset ----
  .try_normals <- function(sdata, element, agg_fun = mean) {
    elem_data <- subset(sdata, ELEMENT == element)
    if (nrow(elem_data) == 0) return(NULL)

    if (element == "PRCP") {
      # PRCP: sum within month-year first, then average across years
      month_year <- aggregate(VALUE ~ MONTH + YEAR, data = elem_data,
                              FUN = sum, na.rm = TRUE)
      # Check month coverage (how many years per month?)
      month_counts <- table(month_year$MONTH)
    } else {
      month_counts <- table(elem_data$MONTH)
    }

    # Do we have enough months represented?
    months_present <- sum(month_counts >= min_years_per_month)
    if (months_present < min_months_required) return(NULL)

    if (element == "PRCP") {
      normals <- aggregate(VALUE ~ MONTH, data = month_year,
                           FUN = mean, na.rm = TRUE)
    } else {
      normals <- aggregate(VALUE ~ MONTH, data = elem_data,
                           FUN = mean, na.rm = TRUE)
    }
    names(normals) <- c("MONTH", "NORMALS")
    return(normals)
  }

  # ---- 1. Try standard WMO period: 1961-1990 ----
  period_label <- "1961-1990"
  normals_data <- subset(station,
                         Ymd >= as.Date("1961-01-01") &
                         Ymd <= as.Date("1990-12-31"))

  TMAX_n <- .try_normals(normals_data, "TMAX")
  TMIN_n <- .try_normals(normals_data, "TMIN")
  PRCP_n <- .try_normals(normals_data, "PRCP")

  all_ok <- !is.null(TMAX_n) && !is.null(TMIN_n) && !is.null(PRCP_n)

  # ---- 2. Fallback: try 1971-2000 ----
  if (!all_ok) {
    period_label <- "1971-2000"
    normals_data <- subset(station,
                           Ymd >= as.Date("1971-01-01") &
                           Ymd <= as.Date("2000-12-31"))
    if (is.null(TMAX_n)) TMAX_n <- .try_normals(normals_data, "TMAX")
    if (is.null(TMIN_n)) TMIN_n <- .try_normals(normals_data, "TMIN")
    if (is.null(PRCP_n)) PRCP_n <- .try_normals(normals_data, "PRCP")
    all_ok <- !is.null(TMAX_n) && !is.null(TMIN_n) && !is.null(PRCP_n)
  }

  # ---- 3. Fallback: try 1981-2010 ----
  if (!all_ok) {
    period_label <- "1981-2010"
    normals_data <- subset(station,
                           Ymd >= as.Date("1981-01-01") &
                           Ymd <= as.Date("2010-12-31"))
    if (is.null(TMAX_n)) TMAX_n <- .try_normals(normals_data, "TMAX")
    if (is.null(TMIN_n)) TMIN_n <- .try_normals(normals_data, "TMIN")
    if (is.null(PRCP_n)) PRCP_n <- .try_normals(normals_data, "PRCP")
    all_ok <- !is.null(TMAX_n) && !is.null(TMIN_n) && !is.null(PRCP_n)
  }

  # ---- 4. Last resort: full record ----
  if (!all_ok) {
    period_label <- "full record"
    if (is.null(TMAX_n)) TMAX_n <- .try_normals(station, "TMAX")
    if (is.null(TMIN_n)) TMIN_n <- .try_normals(station, "TMIN")
    if (is.null(PRCP_n)) PRCP_n <- .try_normals(station, "PRCP")
    all_ok <- !is.null(TMAX_n) && !is.null(TMIN_n) && !is.null(PRCP_n)
  }

  # ---- 5. If STILL not enough data, return NULL with warning ----
  if (!all_ok) {
    missing_elements <- c(
      if (is.null(TMAX_n)) "TMAX",
      if (is.null(TMIN_n)) "TMIN",
      if (is.null(PRCP_n)) "PRCP"
    )
    warning("Station ", station_id,
            ": Cannot compute normals for ", paste(missing_elements, collapse = ", "),
            ". Not enough monthly coverage (need ", min_months_required,
            " months with >= ", min_years_per_month, " years each). Skipping.")
    return(NULL)
  }

  # Report if we fell back from the standard period
  if (period_label != "1961-1990") {
    message("Station ", station_id,
            ": Normals period = ", period_label,
            " (1961-1990 had insufficient data)")
  }

  result <- list(TMAX = TMAX_n, TMIN = TMIN_n, PRCP = PRCP_n)
  attr(result, "normals_period") <- period_label
  return(result)
}

#' Calculate Monthly Anomalies
#'
#' @param station.monthly Output from MonthlyValues.fun
#' @param station.normals Output from MonthlyNormals.fun
#' @param station_id Optional station ID for warning messages
#' @return List with anomaly data frames, or NULL if merge produces no rows.
#' @export
MonthlyAnomalies.fun <- function(station.monthly, station.normals,
                                  station_id = "unknown") {

  # Guard: if normals are NULL the caller should have already handled this,
  # but be safe.
  if (is.null(station.normals)) {
    warning("Station ", station_id, ": normals are NULL, cannot compute anomalies.")
    return(NULL)
  }

  TMAX <- merge(station.monthly$TMAX, station.normals$TMAX, by = "MONTH")
  TMIN <- merge(station.monthly$TMIN, station.normals$TMIN, by = "MONTH")
  PRCP <- merge(station.monthly$PRCP, station.normals$PRCP, by = "MONTH")

  # Check that merges produced rows
  if (nrow(TMAX) == 0 || nrow(TMIN) == 0 || nrow(PRCP) == 0) {
    missing_elem <- c(
      if (nrow(TMAX) == 0) "TMAX",
      if (nrow(TMIN) == 0) "TMIN",
      if (nrow(PRCP) == 0) "PRCP"
    )
    warning("Station ", station_id,
            ": Anomaly merge produced 0 rows for ",
            paste(missing_elem, collapse = ", "),
            ". Normals months may not match data months. Skipping.")
    return(NULL)
  }

  TMAX$TMAX.a <- TMAX$TMAX - TMAX$NORMALS
  TMAX$Ymd <- as.Date(paste(TMAX$YEAR, TMAX$MONTH, "01", sep = "-"))

  TMIN$TMIN.a <- TMIN$TMIN - TMIN$NORMALS
  TMIN$Ymd <- as.Date(paste(TMIN$YEAR, TMIN$MONTH, "01", sep = "-"))

  PRCP$PRCP.a <- PRCP$PRCP - PRCP$NORMALS
  PRCP$Ymd <- as.Date(paste(PRCP$YEAR, PRCP$MONTH, "01", sep = "-"))

  return(list(TMAX = TMAX, TMIN = TMIN, PRCP = PRCP))
}

#' Calculate Monthly Trends (OLS)
#'
#' Fits ordinary least-squares linear regression trends per month per element.
#' This is the default (and simplest) trend method. See
#' \code{\link{monthlyTrend_robust.fun}} for a robust alternative using
#' Theil-Sen slopes and Mann-Kendall significance tests.
#'
#' @param station.anomalies Output from MonthlyAnomalies.fun
#' @return Data frame with trend statistics including Estimate (slope per year),
#'   Std.Error, t.value, p-value, r.squared, and significance stars.
#'
#' @seealso \code{\link{monthlyTrend_robust.fun}} for robust non-parametric trends
#'
#' @export
monthlyTrend.fun <- function(station.anomalies) {

  if (is.null(station.anomalies)) return(data.frame())

  results <- data.frame()

  for (element in c("TMAX", "TMIN", "PRCP")) {
    data <- station.anomalies[[element]]
    if (is.null(data) || nrow(data) == 0) next

    anom_col <- paste0(element, ".a")

    for (m in 1:12) {
      month_data <- subset(data, MONTH == m)

      if (nrow(month_data) >= 10) {
        formula <- as.formula(paste(anom_col, "~ YEAR"))
        model <- tryCatch(lm(formula, data = month_data),
                          error = function(e) NULL)
        if (is.null(model)) next
        s <- summary(model)

        results <- rbind(results, data.frame(
          MONTH = m,
          ELEMENT = element,
          Estimate = coef(model)[2],
          Std.Error = s$coefficients[2, 2],
          t.value = s$coefficients[2, 3],
          `Pr(>|t|)` = s$coefficients[2, 4],
          r.squared = s$r.squared,
          method = "OLS",
          check.names = FALSE
        ))
      }
    }
  }

  if (nrow(results) > 0) {
    results$Signif <- ""
    results$Signif[results$`Pr(>|t|)` < 0.05]  <- "*"
    results$Signif[results$`Pr(>|t|)` < 0.01]  <- "**"
    results$Signif[results$`Pr(>|t|)` < 0.001] <- "***"
  }

  return(results)
}


#' Calculate Monthly Trends Using Theil-Sen Slope and Mann-Kendall Test
#'
#' A robust non-parametric alternative to \code{\link{monthlyTrend.fun}}.
#' Uses the Theil-Sen estimator (median of all pairwise slopes) for the
#' trend magnitude and the Mann-Kendall test for significance. These methods
#' are resistant to outliers and do not assume normally distributed residuals.
#'
#' @param station.anomalies Output from \code{\link{MonthlyAnomalies.fun}}
#'
#' @return Data frame with columns: MONTH, ELEMENT, Estimate (Theil-Sen slope
#'   per year), tau (Kendall's tau), p.value (two-sided Mann-Kendall p-value),
#'   method ("Theil-Sen"), and significance stars.
#'
#' @details
#' \strong{Theil-Sen slope:} The median of slopes calculated between every pair
#' of data points. Unlike OLS, a single extreme year cannot dominate the estimate.
#'
#' \strong{Mann-Kendall test:} A rank-based test for monotonic trend that uses
#' \code{cor.test(method = "kendall")} from base R. It accounts for tied values
#' and is valid even with autocorrelated data (though power decreases).
#'
#' \strong{When to use this vs OLS:}
#' \itemize{
#'   \item Climate time series often have serial autocorrelation, which inflates
#'     OLS p-values. Mann-Kendall is more conservative.
#'   \item Precipitation data often contain outliers (extreme events). Theil-Sen
#'     is not affected by them.
#'   \item For teaching, OLS is easier to explain. For publication-quality results,
#'     Theil-Sen/Mann-Kendall is preferred.
#' }
#'
#' No additional packages are required — this uses only base R's
#' \code{cor.test(method = "kendall")} and manual pairwise slope computation.
#'
#' @seealso \code{\link{monthlyTrend.fun}} for OLS trends,
#'   \code{\link{process_all_stations}} which accepts a \code{trend_method}
#'   parameter to choose between them.
#'
#' @export
monthlyTrend_robust.fun <- function(station.anomalies) {

  if (is.null(station.anomalies)) return(data.frame())

  results <- data.frame()

  for (element in c("TMAX", "TMIN", "PRCP")) {
    data <- station.anomalies[[element]]
    if (is.null(data) || nrow(data) == 0) next

    anom_col <- paste0(element, ".a")

    for (m in 1:12) {
      month_data <- subset(data, MONTH == m)
      month_data <- month_data[order(month_data$YEAR), ]

      # Need at least 10 years
      if (nrow(month_data) < 10) next

      y <- month_data[[anom_col]]
      x <- month_data$YEAR

      # Remove NAs
      valid <- !is.na(y) & !is.na(x)
      if (sum(valid) < 10) next
      y <- y[valid]
      x <- x[valid]
      n <- length(y)

      tryCatch({
        # ---- Theil-Sen slope: median of all pairwise slopes ----
        slopes <- numeric(0)
        for (i in 1:(n - 1)) {
          for (j in (i + 1):n) {
            if (x[j] != x[i]) {
              slopes <- c(slopes, (y[j] - y[i]) / (x[j] - x[i]))
            }
          }
        }
        ts_slope <- median(slopes)

        # ---- Mann-Kendall via cor.test(method = "kendall") ----
        mk <- cor.test(x, y, method = "kendall")

        results <- rbind(results, data.frame(
          MONTH = m,
          ELEMENT = element,
          Estimate = ts_slope,
          tau = unname(mk$estimate),
          p.value = mk$p.value,
          method = "Theil-Sen",
          check.names = FALSE,
          stringsAsFactors = FALSE
        ))
      }, error = function(e) {
        # Skip this month if anything fails
      })
    }
  }

  if (nrow(results) > 0) {
    results$Signif <- ""
    results$Signif[results$p.value < 0.05]  <- "*"
    results$Signif[results$p.value < 0.01]  <- "**"
    results$Signif[results$p.value < 0.001] <- "***"
  }

  return(results)
}


#' Calculate Nonlinear Trends Using Generalized Additive Models
#'
#' Fits a GAM smooth to annual anomalies using \code{mgcv::gam()}, capturing
#' nonlinear trends that a straight line would miss (e.g., flat then rapid
#' warming, or acceleration/deceleration of trends).
#'
#' @param station.anomalies Output from \code{\link{MonthlyAnomalies.fun}}
#' @param k Maximum basis dimension for the smooth (default 10). Higher values
#'   allow more complex curves but risk overfitting short records. The actual
#'   effective degrees of freedom (edf) will be less than k.
#'
#' @return Data frame with columns: ELEMENT, edf (effective degrees of freedom;
#'   1 means linear), GCV (generalized cross-validation score), dev_explained
#'   (proportion of deviance explained, like R-squared), linear_slope (OLS
#'   slope for comparison), smooth_range (range of the fitted smooth, measuring
#'   total change), p_smooth (p-value for the smooth term), and method.
#'
#' @details
#' Instead of fitting monthly trends, this function works on \emph{annual}
#' anomalies (averaged across all months in each year) to provide a single
#' curve per element. This is because GAM smooths are most interpretable on
#' annual or seasonal timescales.
#'
#' \strong{Interpreting edf:}
#' \itemize{
#'   \item edf close to 1 = trend is approximately linear (GAM agrees with OLS)
#'   \item edf of 2-3 = moderate curvature (e.g., acceleration)
#'   \item edf > 4 = highly nonlinear (possible changepoint or oscillation)
#' }
#'
#' Requires the \pkg{mgcv} package, which ships with base R (no extra install).
#'
#' @seealso \code{\link{monthlyTrend.fun}}, \code{\link{monthlyTrend_robust.fun}}
#'
#' @export
nonlinearTrend.fun <- function(station.anomalies, k = 10) {

  if (is.null(station.anomalies)) return(data.frame())

  if (!requireNamespace("mgcv", quietly = TRUE)) {
    warning("Package 'mgcv' not available. Skipping nonlinear trend analysis.")
    return(data.frame())
  }

  results <- data.frame()

  for (element in c("TMAX", "TMIN", "PRCP")) {
    data <- station.anomalies[[element]]
    if (is.null(data) || nrow(data) == 0) next

    anom_col <- paste0(element, ".a")

    # Aggregate to annual anomalies
    annual <- aggregate(
      as.formula(paste(anom_col, "~ YEAR")),
      data = data,
      FUN = mean, na.rm = TRUE
    )
    names(annual) <- c("YEAR", "anomaly")
    annual <- annual[!is.na(annual$anomaly), ]

    # Need enough years for a meaningful smooth
    if (nrow(annual) < 15) next

    tryCatch({
      # Adjust k if we have fewer unique years than k
      k_use <- min(k, nrow(annual) - 2)
      if (k_use < 3) next

      gam_fit <- mgcv::gam(anomaly ~ s(YEAR, k = k_use), data = annual)
      gam_sum <- summary(gam_fit)

      # Also fit OLS for comparison
      lm_fit <- lm(anomaly ~ YEAR, data = annual)

      # Get fitted values for smooth range
      pred <- predict(gam_fit, type = "response")

      results <- rbind(results, data.frame(
        ELEMENT = element,
        edf = round(gam_sum$s.table[1, "edf"], 2),
        GCV = round(gam_fit$gcv.ubre, 4),
        dev_explained = round(gam_sum$dev.expl, 4),
        linear_slope = round(coef(lm_fit)[2] * 100, 3),  # per century
        smooth_range = round(max(pred) - min(pred), 3),
        p_smooth = gam_sum$s.table[1, "p-value"],
        method = "GAM",
        stringsAsFactors = FALSE
      ))

    }, error = function(e) {
      # Skip this element if GAM fitting fails
    })
  }

  return(results)
}


#' Calculate Extreme Precipitation Indices
#'
#' Computes station-level precipitation intensity and frequency indices,
#' following the ETCCDI (Expert Team on Climate Change Detection and Indices)
#' framework. These capture whether rainfall is becoming more intense even
#' if totals are not changing.
#'
#' @param station Cleaned station data (must contain Ymd, ELEMENT, VALUE, YEAR, MONTH).
#'   Values must already be in mm (run \code{\link{fixValues.fun}} first).
#' @param min_days_per_year Minimum number of non-missing PRCP days in a year
#'   for that year to be included. Default 330.
#' @param heavy_threshold_mm Threshold for a "heavy precipitation day" in mm.
#'   Default 25.4 (= 1 inch, a common climatological threshold).
#'
#' @return Data frame with one row per year and columns:
#' \describe{
#'   \item{YEAR}{Calendar year}
#'   \item{annual_total}{Total precipitation (mm)}
#'   \item{wet_days}{Number of days with PRCP > 0}
#'   \item{heavy_days}{Number of days with PRCP >= heavy_threshold_mm}
#'   \item{max_daily}{Maximum single-day precipitation (mm)}
#'   \item{intensity}{Mean precipitation on wet days (mm/day) = SDII index}
#'   \item{pct_heavy}{Fraction of annual total falling on heavy days}
#'   \item{dry_spell_max}{Longest consecutive run of dry days (PRCP = 0)}
#' }
#' Returns NULL if there are fewer than 10 qualifying years.
#'
#' @details
#' \strong{ETCCDI indices computed:}
#' \itemize{
#'   \item \strong{SDII} (Simple Daily Intensity Index): mean precipitation on
#'     wet days (PRCP > 0). Rising SDII means rain events are getting heavier.
#'   \item \strong{R25mm}: count of days with PRCP >= 25mm. Increasing R25mm
#'     means more frequent heavy rain events.
#'   \item \strong{Rx1day}: annual maximum 1-day precipitation. Rising Rx1day
#'     means the most extreme storms are intensifying.
#'   \item \strong{CDD} (Consecutive Dry Days): longest dry spell in each year.
#' }
#'
#' Trends in these indices are computed by \code{\link{process_all_stations}}
#' when \code{compute_extreme_precip = TRUE}.
#'
#' @seealso \code{\link{process_all_stations}}, \code{\link{MonthlyValues.fun}}
#'
#' @export
ExtremePrecp.fun <- function(station,
                              min_days_per_year = 330,
                              heavy_threshold_mm = 25.4) {

  prcp <- subset(station, ELEMENT == "PRCP")
  if (nrow(prcp) == 0) return(NULL)

  # Need Ymd and YEAR columns
  if (!"Ymd" %in% names(prcp) || !"YEAR" %in% names(prcp)) {
    stop("Run fixDates.fun() before ExtremePrecp.fun()")
  }

  # ---- helper: max consecutive dry days in a vector ----
  .max_dry_spell <- function(values) {
    if (length(values) == 0) return(NA)
    is_dry <- values == 0 | is.na(values)
    rle_dry <- rle(is_dry)
    dry_runs <- rle_dry$lengths[rle_dry$values]
    if (length(dry_runs) == 0) return(0)
    return(max(dry_runs))
  }

  # Count non-missing days per year
  year_counts <- aggregate(VALUE ~ YEAR, data = prcp,
                           FUN = function(x) sum(!is.na(x)))
  names(year_counts) <- c("YEAR", "n_days")
  valid_years <- year_counts$YEAR[year_counts$n_days >= min_days_per_year]

  if (length(valid_years) < 10) return(NULL)

  prcp_valid <- prcp[prcp$YEAR %in% valid_years & !is.na(prcp$VALUE), ]

  results <- data.frame()
  for (yr in valid_years) {
    yr_data <- prcp_valid[prcp_valid$YEAR == yr, ]
    vals <- yr_data$VALUE

    wet <- vals[vals > 0]
    heavy <- vals[vals >= heavy_threshold_mm]

    total <- sum(vals, na.rm = TRUE)
    heavy_total <- sum(heavy, na.rm = TRUE)

    results <- rbind(results, data.frame(
      YEAR = yr,
      annual_total = total,
      wet_days = length(wet),
      heavy_days = length(heavy),
      max_daily = max(vals, na.rm = TRUE),
      intensity = if (length(wet) > 0) mean(wet) else NA,
      pct_heavy = if (total > 0) heavy_total / total else NA,
      dry_spell_max = .max_dry_spell(vals)
    ))
  }

  return(results)
}


#' Fit Linear Trends to Extreme Precipitation Indices
#'
#' Internal helper that fits OLS or Theil-Sen trends to the annual extreme
#' precipitation indices from \code{\link{ExtremePrecp.fun}}.
#'
#' @param extreme_df Data frame from ExtremePrecp.fun
#' @param method \code{"OLS"} or \code{"Theil-Sen"}
#' @return Named numeric vector of per-century trends for each index.
#'
#' @keywords internal
#' @noRd
.fit_extreme_trends <- function(extreme_df, method = "OLS") {

  if (is.null(extreme_df) || nrow(extreme_df) < 10) {
    return(list(
      trend_intensity = NA, trend_heavy_days = NA, trend_max_daily = NA,
      trend_pct_heavy = NA, trend_dry_spell = NA
    ))
  }

  indices <- c("intensity", "heavy_days", "max_daily", "pct_heavy", "dry_spell_max")
  out <- list()

  for (idx in indices) {
    df <- extreme_df[!is.na(extreme_df[[idx]]), ]
    if (nrow(df) < 10) {
      out[[paste0("trend_", idx)]] <- NA
      next
    }

    tryCatch({
      if (method == "Theil-Sen") {
        x <- df$YEAR
        y <- df[[idx]]
        n <- length(x)
        slopes <- numeric(0)
        for (i in 1:(n - 1)) {
          for (j in (i + 1):n) {
            if (x[j] != x[i]) {
              slopes <- c(slopes, (y[j] - y[i]) / (x[j] - x[i]))
            }
          }
        }
        out[[paste0("trend_", idx)]] <- median(slopes) * 100  # per century
      } else {
        model <- lm(as.formula(paste(idx, "~ YEAR")), data = df)
        out[[paste0("trend_", idx)]] <- coef(model)[2] * 100  # per century
      }
    }, error = function(e) {
      out[[paste0("trend_", idx)]] <<- NA
    })
  }

  return(out)
}
