# =============================================================================
# ClimateNarratives - Complete Example Workflow
# =============================================================================
# This script demonstrates a complete climate analysis workflow using the
# ClimateNarratives package, from setup through visualization.
#
# >>> ONLY ONE LINE TO EDIT: change my_state below to YOUR state code <<<
#
# Time required: 30-60 minutes (mostly download time)
# Disk space: ~100-500 MB per state
#
# v0.3.1 additions:
#   - Monthly completeness filtering (fixes biased precipitation trends)
#   - Theil-Sen / Mann-Kendall robust trends
#   - Extreme precipitation indices
#   - GAM nonlinear trend diagnostics
#   - Alaska & Hawaii map boundaries work correctly
# =============================================================================

# =============================================================================
# STEP 1: LOAD PACKAGE
# =============================================================================

library(ClimateNarratives)

cat("ClimateNarratives package loaded!\n")

# =============================================================================
# STEP 2: INITIALIZE PROJECT
# =============================================================================

# +-------------------------------------------------------------------+
# |  EDIT THIS LINE: change "CA" to your state abbreviation           |
# |  Examples: "TX", "NY", "FL", "OR", "AK", "HI", etc.              |
# +-------------------------------------------------------------------+
my_state <- "CA"

# Initialize project -- specify path explicitly so you always know where files go.
# Creates Data/, Output/, and Figures/ subfolders and sets your working directory.
cat("\n=== Initializing Project ===\n")
initialize_project(my_state, path = "~/ClimateNarratives")

# =============================================================================
# STEP 3: SELECT HIGH-QUALITY STATIONS
# =============================================================================

cat("\n=== Selecting Weather Stations ===\n")

select_stations(
  n = 50,
  min_years = 50,
  min_last_year = 2020
)

cat("Selected", nrow(my.inventory), "stations for analysis\n")

# =============================================================================
# STEP 4: DOWNLOAD DATA FROM NOAA
# =============================================================================

cat("\n=== Downloading Data ===\n")
cat("This step takes 10-30 minutes...\n\n")

download_stations()

# =============================================================================
# STEP 5: PROCESS AND SAVE DATA
# =============================================================================

cat("\n=== Processing Downloaded Data ===\n")

load_and_save_stations(cleanup = TRUE)

# =============================================================================
# STEP 6: CALCULATE CLIMATE TRENDS
# =============================================================================

cat("\n=== Analyzing Climate Trends (OLS method) ===\n")

# Default analysis: OLS trends with completeness filtering (v0.3.1)
# The completeness filter requires 20+ days/month for temperature and
# 25+ days/month for precipitation. This prevents biased estimates from
# months with many missing days (especially important for precip totals).
trends <- process_all_stations()

cat("\nTrend Summary (OLS):\n")
cat("Stations with valid trends:", nrow(trends), "\n")
cat("Mean annual TMAX trend:",
    round(mean(trends$annual_trend_TMAX, na.rm = TRUE), 2), "\u00b0C/century\n")
cat("Mean annual TMIN trend:",
    round(mean(trends$annual_trend_TMIN, na.rm = TRUE), 2), "\u00b0C/century\n")
cat("Mean annual PRCP trend:",
    round(mean(trends$annual_trend_PRCP, na.rm = TRUE), 1), "mm/century\n")

# =============================================================================
# STEP 6b: ROBUST TRENDS (v0.3.1 -- optional)
# =============================================================================

cat("\n=== Analyzing Climate Trends (Theil-Sen method) ===\n")

# Theil-Sen slope: median of all pairwise slopes (outlier-resistant)
# Mann-Kendall test: non-parametric significance (handles autocorrelation)
trends_robust <- process_all_stations(
  trend_method = "Theil-Sen",
  compute_extreme_precip = TRUE,
  compute_nonlinear = TRUE
)

cat("\nRobust Trend Summary (Theil-Sen):\n")
cat("Mean annual TMAX trend:",
    round(mean(trends_robust$annual_trend_TMAX, na.rm = TRUE), 2), "\u00b0C/century\n")

# Compare OLS vs Theil-Sen
if ("annual_trend_TMAX" %in% names(trends) &&
    "annual_trend_TMAX" %in% names(trends_robust)) {
  cat("\nOLS vs Theil-Sen comparison:\n")
  cat("  OLS mean TMAX trend:      ",
      round(mean(trends$annual_trend_TMAX, na.rm = TRUE), 3), "\n")
  cat("  Theil-Sen mean TMAX trend:",
      round(mean(trends_robust$annual_trend_TMAX, na.rm = TRUE), 3), "\n")
}

# Extreme precipitation results
if ("trend_intensity" %in% names(trends_robust)) {
  cat("\nExtreme Precipitation Trends (per century):\n")
  cat("  Intensity (SDII):",
      round(mean(trends_robust$trend_intensity, na.rm = TRUE), 3), "mm/day\n")
  cat("  Heavy days (>=25mm):",
      round(mean(trends_robust$trend_heavy_days, na.rm = TRUE), 2), "days\n")
  cat("  Max daily precip:",
      round(mean(trends_robust$trend_max_daily, na.rm = TRUE), 2), "mm\n")
}

# Nonlinear diagnostics
if ("gam_edf_TMAX" %in% names(trends_robust)) {
  mean_edf <- mean(trends_robust$gam_edf_TMAX, na.rm = TRUE)
  cat("\nNonlinear Trend Diagnostics:\n")
  cat("  Mean GAM edf (TMAX):", round(mean_edf, 2), "\n")
  if (mean_edf > 2) {
    cat("  >> Nonlinear trends detected -- warming may be accelerating\n")
  } else {
    cat("  >> Trends are approximately linear\n")
  }
}

# =============================================================================
# STEP 7: CREATE SPATIAL OBJECTS
# =============================================================================

cat("\n=== Creating Spatial Objects ===\n")

# Use the robust trends for mapping (or switch to `trends` for OLS)
create_spatial_objects(trends_robust)

# =============================================================================
# STEP 8: CREATE HEAT MAPS
# =============================================================================

cat("\n=== Generating Heat Maps ===\n")

# Annual Maximum Temperature Trend
cat("Creating TMAX heat map...\n")
map_tmax <- create_heatmap(
  trends_sp,
  trend_var = "annual_trend_TMAX",
  title = paste(my.state, "- Annual Maximum Temperature Trend"),
  subtitle = "Change in \u00b0C per 100 years (Theil-Sen)",
  state = my.state,
  colors = "temp"
)

ggsave(paste0(figuresfolder, "TMAX_annual_", my.state, ".png"),
       map_tmax, width = 10, height = 8, dpi = 300)

# Annual Minimum Temperature Trend
cat("Creating TMIN heat map...\n")
map_tmin <- create_heatmap(
  trends_sp,
  trend_var = "annual_trend_TMIN",
  title = paste(my.state, "- Annual Minimum Temperature Trend"),
  subtitle = "Change in \u00b0C per 100 years (Theil-Sen)",
  state = my.state,
  colors = "temp"
)

ggsave(paste0(figuresfolder, "TMIN_annual_", my.state, ".png"),
       map_tmin, width = 10, height = 8, dpi = 300)

# Annual Precipitation Trend
cat("Creating precipitation heat map...\n")
map_prcp <- create_heatmap(
  trends_sp,
  trend_var = "annual_trend_PRCP",
  title = paste(my.state, "- Annual Precipitation Trend"),
  subtitle = "Change in mm per 100 years (Theil-Sen)",
  state = my.state,
  colors = "precip"
)

ggsave(paste0(figuresfolder, "PRCP_annual_", my.state, ".png"),
       map_prcp, width = 10, height = 8, dpi = 300)

# =============================================================================
# STEP 8b: EXTREME PRECIPITATION MAPS (v0.3.1)
# =============================================================================

if ("trend_intensity" %in% names(trends_robust)) {
  cat("Creating extreme precipitation maps...\n")

  # Precipitation intensity trend
  map_intensity <- create_heatmap(
    trends_sp,
    trend_var = "trend_intensity",
    title = paste(my.state, "- Precipitation Intensity Trend (SDII)"),
    subtitle = "Change in mean wet-day precipitation (mm/day per century)",
    state = my.state,
    colors = "precip"
  )
  ggsave(paste0(figuresfolder, "PRCP_intensity_", my.state, ".png"),
         map_intensity, width = 10, height = 8, dpi = 300)

  # Heavy precipitation day trend
  map_heavy <- create_heatmap(
    trends_sp,
    trend_var = "trend_heavy_days",
    title = paste(my.state, "- Heavy Precipitation Days Trend"),
    subtitle = "Change in days >= 25mm per century",
    state = my.state,
    colors = "precip"
  )
  ggsave(paste0(figuresfolder, "PRCP_heavy_days_", my.state, ".png"),
         map_heavy, width = 10, height = 8, dpi = 300)
}

# =============================================================================
# STEP 9: CREATE SEASONAL COMPARISON
# =============================================================================

cat("\n=== Creating Seasonal Comparison ===\n")

library(patchwork)

winter_map <- create_heatmap(trends_sp, "winter_trend_TMAX",
                             "Winter (Dec-Feb)", state = my.state,
                             resolution = 0.15) +
  theme(legend.position = "none")

spring_map <- create_heatmap(trends_sp, "spring_trend_TMAX",
                             "Spring (Mar-May)", state = my.state,
                             resolution = 0.15) +
  theme(legend.position = "none")

summer_map <- create_heatmap(trends_sp, "summer_trend_TMAX",
                             "Summer (Jun-Aug)", state = my.state,
                             resolution = 0.15) +
  theme(legend.position = "right")

fall_map <- create_heatmap(trends_sp, "fall_trend_TMAX",
                           "Fall (Sep-Nov)", state = my.state,
                           resolution = 0.15) +
  theme(legend.position = "none")

seasonal_panel <- (winter_map | spring_map) / (summer_map | fall_map) +
  plot_annotation(
    title = paste("Seasonal TMAX Trends -", my.state),
    subtitle = "Change in \u00b0C per 100 years by season"
  )

ggsave(paste0(figuresfolder, "Seasonal_TMAX_", my.state, ".png"),
       seasonal_panel, width = 12, height = 10, dpi = 300)

# =============================================================================
# STEP 10: SUMMARY AND NEXT STEPS
# =============================================================================

cat("\n")
cat("===========================================================\n")
cat("  ANALYSIS COMPLETE! (v0.3.1)\n")
cat("===========================================================\n")
cat("State:", my.state, "\n")
cat("Stations analyzed:", nrow(trends_robust), "\n")
cat("Trend method: Theil-Sen (robust)\n")
cat("\nFiles created in:", figuresfolder, "\n")
cat("  - TMAX_annual_", my.state, ".png\n", sep = "")
cat("  - TMIN_annual_", my.state, ".png\n", sep = "")
cat("  - PRCP_annual_", my.state, ".png\n", sep = "")
if ("trend_intensity" %in% names(trends_robust)) {
  cat("  - PRCP_intensity_", my.state, ".png\n", sep = "")
  cat("  - PRCP_heavy_days_", my.state, ".png\n", sep = "")
}
cat("  - Seasonal_TMAX_", my.state, ".png\n", sep = "")
cat("===========================================================\n")
cat("\nNEXT STEPS:\n")
cat("1. View heat maps in Figures/ folder\n")
cat("2. Compare OLS vs Theil-Sen trends\n")
cat("3. Examine extreme precipitation patterns\n")
cat("4. Check GAM edf to see if warming is accelerating\n")
cat("5. Explore seasonal and regional differences\n")
cat("6. Create visualizations for your narrative video\n")
cat("===========================================================\n\n")

# =============================================================================
# ADDITIONAL ANALYSIS IDEAS
# =============================================================================

# Uncomment to explore further:

# # Compare OLS and Theil-Sen results side by side
# comparison <- data.frame(
#   Station = trends$ID,
#   OLS_TMAX = trends$annual_trend_TMAX,
#   TS_TMAX = trends_robust$annual_trend_TMAX[match(trends$ID, trends_robust$ID)]
# )
# plot(TS_TMAX ~ OLS_TMAX, data = comparison,
#      main = "OLS vs Theil-Sen TMAX Trends",
#      xlab = "OLS Trend (deg C/century)",
#      ylab = "Theil-Sen Trend (deg C/century)")
# abline(0, 1, lty = 2, col = "red")
#
# # Plot precipitation intensity trend vs total precipitation trend
# if ("trend_intensity" %in% names(trends_robust)) {
#   plot(trend_intensity ~ annual_trend_PRCP, data = trends_robust,
#        main = "Total vs Intensity Precipitation Trends",
#        xlab = "Total PRCP Trend (mm/century)",
#        ylab = "Intensity Trend (mm/day per century)")
#   abline(h = 0, v = 0, lty = 2)
# }
#
# # Identify stations with nonlinear warming
# if ("gam_edf_TMAX" %in% names(trends_robust)) {
#   nonlinear <- trends_robust[trends_robust$gam_edf_TMAX > 2, ]
#   cat("Stations with nonlinear TMAX trends (edf > 2):\n")
#   print(nonlinear[, c("ID", "NAME", "gam_edf_TMAX", "annual_trend_TMAX")])
# }

cat("Workflow complete! Happy analyzing!\n\n")
