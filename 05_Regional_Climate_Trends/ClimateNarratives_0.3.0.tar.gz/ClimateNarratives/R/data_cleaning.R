#' Fix Date Formats in Station Data
#'
#' Converts NOAA's integer date format (YYYYMMDD) to proper R Date objects
#' and extracts MONTH and YEAR columns for aggregation.
#'
#' @param station Data frame with station data containing DATE column in
#'   NOAA format (e.g., 20230715 for July 15, 2023)
#'
#' @return Data frame with three new columns:
#' \itemize{
#'   \item Ymd - Proper R Date object
#'   \item MONTH - Month as integer (1-12)
#'   \item YEAR - Four-digit year
#' }
#'
#' @export
fixDates.fun <- function(station) {
  station$Ymd <- as.Date(as.character(station$DATE), format = "%Y%m%d")
  station$MONTH <- as.numeric(format(station$Ymd, "%m"))
  station$YEAR <- as.numeric(format(station$Ymd, "%Y"))
  return(station)
}

#' Convert NOAA Value Units to Standard Units
#' @param station Data frame with station data
#' @return Data frame with converted values
#' @export
fixValues.fun <- function(station) {
  temp_idx <- station$ELEMENT %in% c("TMAX", "TMIN")
  station$VALUE[temp_idx] <- station$VALUE[temp_idx] / 10
  prcp_idx <- station$ELEMENT == "PRCP"
  station$VALUE[prcp_idx] <- station$VALUE[prcp_idx] / 10
  snow_idx <- station$ELEMENT %in% c("SNOW", "SNWD")
  station$VALUE[snow_idx] <- station$VALUE[snow_idx] / 10
  return(station)
}

#' Calculate Data Coverage Percentage
#' @param station Data frame with station data
#' @param element Element to check
#' @return Coverage percentage
#' @export
coverage.fun <- function(station, element = "TMAX") {
  if (!"Ymd" %in% names(station)) {
    stop("Run fixDates.fun() first")
  }
  Dates.all <- data.frame(Ymd = seq.Date(
    from = min(station$Ymd, na.rm = TRUE),
    to = max(station$Ymd, na.rm = TRUE),
    by = "day"
  ))
  station.full <- merge(Dates.all, station, all = TRUE)
  coverage <- sum(!is.na(station.full$VALUE[station.full$ELEMENT == element])) /
    length(station.full$VALUE[station.full$ELEMENT == element]) * 100
  return(round(coverage, 2))
}
