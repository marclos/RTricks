#!/usr/bin/env Rscript

# =============================================================================
# ClimateNarratives v0.2.0 Installation Script
# =============================================================================

cat("\n")
cat("===========================================================\n")
cat("  ClimateNarratives v0.2.0 Installer\n")
cat("===========================================================\n\n")

# Check for required packages
cat("Step 1: Checking for required packages...\n")

required_pkgs <- c("devtools", "roxygen2", "dplyr", "tidyr", "ggplot2", 
                   "sf", "sp", "gstat", "stars", "maps", "viridis", 
                   "lubridate", "patchwork")

missing_pkgs <- c()
for (pkg in required_pkgs) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    missing_pkgs <- c(missing_pkgs, pkg)
  }
}

if (length(missing_pkgs) > 0) {
  cat("  Installing missing packages:", paste(missing_pkgs, collapse = ", "), "\n")
  install.packages(missing_pkgs, repos = "https://cloud.r-project.org")
} else {
  cat("  ✓ All required packages available\n")
}

cat("\n")

# Remove old version if exists
cat("Step 2: Removing old version (if present)...\n")
tryCatch({
  remove.packages("ClimateNarratives")
  cat("  ✓ Old version removed\n")
}, error = function(e) {
  cat("  (No old version found)\n")
})

cat("\n")

# Install package
cat("Step 3: Installing ClimateNarratives v0.2.0...\n")

# Try to find the tar.gz file
if (file.exists("ClimateNarratives_0.2.tar.gz")) {
  install.packages("ClimateNarratives_0.2.tar.gz", repos = NULL, type = "source")
} else if (dir.exists("ClimateNarratives")) {
  devtools::install("ClimateNarratives")
} else {
  stop("Cannot find ClimateNarratives package files!")
}

cat("\n")
cat("===========================================================\n")
cat("  Installation Complete!\n")
cat("===========================================================\n\n")

cat("Test the installation:\n")
cat("  library(ClimateNarratives)\n")
cat("  ?ClimateNarratives\n")
cat("  initialize_project('CA')\n\n")

cat("===========================================================\n\n")
