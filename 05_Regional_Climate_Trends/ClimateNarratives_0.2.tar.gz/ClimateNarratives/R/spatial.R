#' Process All Stations for Spatial Analysis
#'
#' Processes all downloaded stations to calculate climate trends for mapping.
#' Calculates annual and seasonal trends for TMAX, TMIN, and PRCP.
#'
#' @param verbose Logical. Show progress messages (default = TRUE)
#'
#' @return Data frame with one row per station containing:
#' \itemize{
#'   \item Station metadata (ID, name, coordinates, elevation)
#'   \item Annual trends for TMAX, TMIN, PRCP
#'   \item Seasonal trends (winter, spring, summer, fall) for each variable
#' }
#'
#' @details
#' For each station, this function:
#' \enumerate{
#'   \item Fixes dates and values
#'   \item Calculates monthly aggregates
#'   \item Computes climate normals (1961-1990)
#'   \item Calculates anomalies
#'   \item Fits linear trends for annual and seasonal data
#' }
#'
#' Seasons are defined as:
#' \itemize{
#'   \item Winter: December-February
#'   \item Spring: March-May
#'   \item Summer: June-August
#'   \item Fall: September-November
#' }
#'
#' @examples
#' \dontrun{
#' # After loading stations
#' trends <- process_all_stations()
#' summary(trends$annual_trend_TMAX)
#' }
#'
#' @export
process_all_stations <- function(verbose = TRUE) {
  
  if (!exists("station_list", envir = .GlobalEnv)) {
    stop("Run load_stations() or load_and_save_stations() first!")
  }
  
  station_list <- get("station_list", envir = .GlobalEnv)
  
  if (verbose) {
    cat("===========================================================\n")
    cat("  Processing Stations for Spatial Analysis\n")
    cat("===========================================================\n")
    cat("Stations to process:", length(station_list), "\n")
    
    # Check for inventory
    has_station_inv <- exists("station_inventory", envir = .GlobalEnv)
    has_my_inv <- exists("my.inventory", envir = .GlobalEnv)
    
    if (has_station_inv) {
      station_inventory <- get("station_inventory", envir = .GlobalEnv)
      cat("Station inventory found:", nrow(station_inventory), "stations\n")
    } else if (has_my_inv) {
      my.inventory <- get("my.inventory", envir = .GlobalEnv)
      cat("Using my.inventory:", nrow(my.inventory), "stations\n")
    } else {
      cat("WARNING: No station inventory found - coordinates may be missing!\n")
      cat("         Run initialize_project() to load station metadata.\n")
    }
    cat("\n")
  }
  
  results <- data.frame()
  
  for (i in seq_along(station_list)) {
    
    station_id <- names(station_list)[i]
    station_data <- station_list[[station_id]]
    
    if (verbose && i %% 10 == 0) {
      cat(sprintf("[%d/%d] Processing...\n", i, length(station_list)))
    }
    
    tryCatch({
      # Fix dates and values
      station_data <- fixDates.fun(station_data)
      station_data <- fixValues.fun(station_data)
      
      # Get monthly values
      monthly <- MonthlyValues.fun(station_data)
      
      # Get normals
      normals <- MonthlyNormals.fun(station_data)
      
      # Get anomalies
      anomalies <- MonthlyAnomalies.fun(monthly, normals)
      
      # Calculate annual trends
      annual_tmax <- calculate_annual_trend(anomalies$TMAX, "TMAX.a")
      annual_tmin <- calculate_annual_trend(anomalies$TMIN, "TMIN.a")
      annual_prcp <- calculate_annual_trend(anomalies$PRCP, "PRCP.a")
      
      # Calculate seasonal trends
      seasonal_tmax <- calculate_seasonal_trends(anomalies$TMAX, "TMAX.a")
      seasonal_tmin <- calculate_seasonal_trends(anomalies$TMIN, "TMIN.a")
      seasonal_prcp <- calculate_seasonal_trends(anomalies$PRCP, "PRCP.a")
      
      # Get station metadata - try multiple sources
      station_meta <- NULL
      
      # First try station_inventory (from load_and_save_stations)
      if (exists("station_inventory", envir = .GlobalEnv)) {
        inventory <- get("station_inventory", envir = .GlobalEnv)
        station_meta <- inventory[inventory$ID == station_id, ]
      }
      
      # Fallback to my.inventory if available
      if (is.null(station_meta) || nrow(station_meta) == 0) {
        if (exists("my.inventory", envir = .GlobalEnv)) {
          inventory <- get("my.inventory", envir = .GlobalEnv)
          station_meta <- inventory[inventory$ID == station_id, ]
        }
      }
      
      # Last resort: create empty metadata
      if (is.null(station_meta) || nrow(station_meta) == 0) {
        station_meta <- data.frame(
          ID = station_id,
          LATITUDE = NA,
          LONGITUDE = NA,
          ELEVATION = NA,
          NAME = station_id,
          stringsAsFactors = FALSE
        )
      }
      
      # Combine results
      station_result <- data.frame(
        ID = station_id,
        LATITUDE = station_meta$LATITUDE[1],
        LONGITUDE = station_meta$LONGITUDE[1],
        ELEVATION = station_meta$ELEVATION[1],
        NAME = station_meta$NAME[1],
        annual_trend_TMAX = annual_tmax * 100,  # Convert to per century
        annual_trend_TMIN = annual_tmin * 100,
        annual_trend_PRCP = annual_prcp * 100,
        winter_trend_TMAX = seasonal_tmax["winter"] * 100,
        spring_trend_TMAX = seasonal_tmax["spring"] * 100,
        summer_trend_TMAX = seasonal_tmax["summer"] * 100,
        fall_trend_TMAX = seasonal_tmax["fall"] * 100,
        winter_trend_TMIN = seasonal_tmin["winter"] * 100,
        spring_trend_TMIN = seasonal_tmin["spring"] * 100,
        summer_trend_TMIN = seasonal_tmin["summer"] * 100,
        fall_trend_TMIN = seasonal_tmin["fall"] * 100,
        winter_trend_PRCP = seasonal_prcp["winter"] * 100,
        spring_trend_PRCP = seasonal_prcp["spring"] * 100,
        summer_trend_PRCP = seasonal_prcp["summer"] * 100,
        fall_trend_PRCP = seasonal_prcp["fall"] * 100,
        stringsAsFactors = FALSE
      )
      
      results <- rbind(results, station_result)
      
    }, error = function(e) {
      if (verbose) {
        warning("Failed to process station ", station_id, ": ", conditionMessage(e))
      }
    })
  }
  
  if (verbose) {
    n_valid_coords <- sum(!is.na(results$LATITUDE) & !is.na(results$LONGITUDE))
    cat("\n[OK] Processed", nrow(results), "stations successfully\n")
    cat("     Stations with valid coordinates:", n_valid_coords, "\n")
    
    if (n_valid_coords < nrow(results)) {
      cat("\n⚠ WARNING:", nrow(results) - n_valid_coords, "stations missing coordinates!\n")
      cat("  These stations will be dropped in create_spatial_objects().\n")
      cat("  To fix: Make sure station_inventory or my.inventory exists.\n")
    }
    cat("===========================================================\n\n")
    
    # Climate Trend Summary
    cat("===========================================================\n")
    cat("  CLIMATE TREND SUMMARY\n")
    cat("===========================================================\n\n")
    
    # Temperature trends
    cat("ANNUAL TEMPERATURE TRENDS (°C per 100 years):\n")
    cat("  Maximum Temperature (TMAX):\n")
    cat(sprintf("    Mean:   %+.3f°C/century\n", mean(results$annual_trend_TMAX, na.rm = TRUE)))
    cat(sprintf("    Median: %+.3f°C/century\n", median(results$annual_trend_TMAX, na.rm = TRUE)))
    cat(sprintf("    Range:  %+.3f to %+.3f°C/century\n", 
                min(results$annual_trend_TMAX, na.rm = TRUE),
                max(results$annual_trend_TMAX, na.rm = TRUE)))
    
    cat("\n  Minimum Temperature (TMIN):\n")
    cat(sprintf("    Mean:   %+.3f°C/century\n", mean(results$annual_trend_TMIN, na.rm = TRUE)))
    cat(sprintf("    Median: %+.3f°C/century\n", median(results$annual_trend_TMIN, na.rm = TRUE)))
    cat(sprintf("    Range:  %+.3f to %+.3f°C/century\n", 
                min(results$annual_trend_TMIN, na.rm = TRUE),
                max(results$annual_trend_TMIN, na.rm = TRUE)))
    
    # Precipitation trends
    cat("\nANNUAL PRECIPITATION TRENDS (mm per 100 years):\n")
    cat(sprintf("    Mean:   %+.1f mm/century\n", mean(results$annual_trend_PRCP, na.rm = TRUE)))
    cat(sprintf("    Median: %+.1f mm/century\n", median(results$annual_trend_PRCP, na.rm = TRUE)))
    cat(sprintf("    Range:  %+.1f to %+.1f mm/century\n", 
                min(results$annual_trend_PRCP, na.rm = TRUE),
                max(results$annual_trend_PRCP, na.rm = TRUE)))
    
    # Seasonal temperature trends
    cat("\nSEASONAL TMAX TRENDS (°C per 100 years):\n")
    cat(sprintf("    Winter: %+.3f°C/century\n", mean(results$winter_trend_TMAX, na.rm = TRUE)))
    cat(sprintf("    Spring: %+.3f°C/century\n", mean(results$spring_trend_TMAX, na.rm = TRUE)))
    cat(sprintf("    Summer: %+.3f°C/century\n", mean(results$summer_trend_TMAX, na.rm = TRUE)))
    cat(sprintf("    Fall:   %+.3f°C/century\n", mean(results$fall_trend_TMAX, na.rm = TRUE)))
    
    cat("\nSEASONAL TMIN TRENDS (°C per 100 years):\n")
    cat(sprintf("    Winter: %+.3f°C/century\n", mean(results$winter_trend_TMIN, na.rm = TRUE)))
    cat(sprintf("    Spring: %+.3f°C/century\n", mean(results$spring_trend_TMIN, na.rm = TRUE)))
    cat(sprintf("    Summer: %+.3f°C/century\n", mean(results$summer_trend_TMIN, na.rm = TRUE)))
    cat(sprintf("    Fall:   %+.3f°C/century\n", mean(results$fall_trend_TMIN, na.rm = TRUE)))
    
    # Warming interpretation
    cat("\n-----------------------------------------------------------\n")
    cat("INTERPRETATION:\n")
    mean_tmax <- mean(results$annual_trend_TMAX, na.rm = TRUE)
    mean_tmin <- mean(results$annual_trend_TMIN, na.rm = TRUE)
    mean_prcp <- mean(results$annual_trend_PRCP, na.rm = TRUE)
    
    if (mean_tmax > 0) {
      cat(sprintf("• Daytime temperatures WARMING at %.2f°C per 100 years\n", mean_tmax))
    } else {
      cat(sprintf("• Daytime temperatures COOLING at %.2f°C per 100 years\n", abs(mean_tmax)))
    }
    
    if (mean_tmin > 0) {
      cat(sprintf("• Nighttime temperatures WARMING at %.2f°C per 100 years\n", mean_tmin))
    } else {
      cat(sprintf("• Nighttime temperatures COOLING at %.2f°C per 100 years\n", abs(mean_tmin)))
    }
    
    if (abs(mean_tmin) > abs(mean_tmax)) {
      cat("• Nighttime warming exceeds daytime warming (asymmetric)\n")
    } else if (abs(mean_tmax) > abs(mean_tmin)) {
      cat("• Daytime warming exceeds nighttime warming\n")
    }
    
    if (mean_prcp > 0) {
      cat(sprintf("• Precipitation INCREASING at %.1f mm per 100 years\n", mean_prcp))
    } else if (mean_prcp < 0) {
      cat(sprintf("• Precipitation DECREASING at %.1f mm per 100 years\n", abs(mean_prcp)))
    } else {
      cat("• No significant precipitation trend\n")
    }
    
    cat("===========================================================\n\n")
  }
  
  return(results)
}

#' Calculate Annual Trend
#' @keywords internal
calculate_annual_trend <- function(data, var_name) {
  
  # Aggregate to annual
  annual <- aggregate(as.formula(paste(var_name, "~ YEAR")), 
                     data = data, 
                     mean, na.rm = TRUE)
  
  if (nrow(annual) < 10) return(NA)
  
  # Fit linear model
  model <- lm(as.formula(paste(var_name, "~ YEAR")), data = annual)
  
  # Return trend (change per year)
  return(coef(model)[2])
}

#' Calculate Seasonal Trends
#' @keywords internal
calculate_seasonal_trends <- function(data, var_name) {
  
  # Add season column
  data$SEASON <- NA
  data$SEASON[data$MONTH %in% c(12, 1, 2)] <- "winter"
  data$SEASON[data$MONTH %in% c(3, 4, 5)] <- "spring"
  data$SEASON[data$MONTH %in% c(6, 7, 8)] <- "summer"
  data$SEASON[data$MONTH %in% c(9, 10, 11)] <- "fall"
  
  trends <- c(winter = NA, spring = NA, summer = NA, fall = NA)
  
  for (season in c("winter", "spring", "summer", "fall")) {
    season_data <- data[data$SEASON == season, ]
    
    if (nrow(season_data) < 10) next
    
    # Aggregate to annual
    annual <- aggregate(as.formula(paste(var_name, "~ YEAR")), 
                       data = season_data, 
                       mean, na.rm = TRUE)
    
    if (nrow(annual) < 10) next
    
    # Fit linear model
    model <- lm(as.formula(paste(var_name, "~ YEAR")), data = annual)
    
    trends[season] <- coef(model)[2]
  }
  
  return(trends)
}


#' Create Spatial Objects from Trend Data
#'
#' Converts trend data frame to spatial formats (sf and sp) for mapping.
#'
#' @param trends Data frame from \code{\link{process_all_stations}}
#'
#' @return List with two elements:
#' \itemize{
#'   \item trends_sf - Simple Features (sf) object
#'   \item trends_sp - Spatial Points (sp) object
#' }
#'
#' @details
#' Creates spatial point objects with coordinates from station locations.
#' The sp format is needed for kriging interpolation in \code{\link{create_heatmap}}.
#'
#' @examples
#' \dontrun{
#' trends <- process_all_stations()
#' spatial <- create_spatial_objects(trends)
#' }
#'
#' @export
create_spatial_objects <- function(trends) {
  
  # Remove any rows with missing coordinates
  trends <- trends[!is.na(trends$LATITUDE) & !is.na(trends$LONGITUDE), ]
  
  if (nrow(trends) == 0) {
    stop("No valid coordinates found in trends data")
  }
  
  # Create sf object (Simple Features - modern approach)
  trends_sf <- sf::st_as_sf(
    trends,
    coords = c("LONGITUDE", "LATITUDE"),
    crs = 4326,  # WGS84
    remove = FALSE  # Keep coordinate columns
  )
  
  # Create sp object (needed for gstat kriging)
  coords <- trends[, c("LONGITUDE", "LATITUDE")]
  trends_sp <- sp::SpatialPointsDataFrame(
    coords = coords,
    data = trends,
    proj4string = sp::CRS("+proj=longlat +datum=WGS84")
  )
  
  # Assign to global environment for easy access
  assign("trends_sf", trends_sf, envir = .GlobalEnv)
  assign("trends_sp", trends_sp, envir = .GlobalEnv)
  
  cat("[OK] Created spatial objects:\n")
  cat("  - trends_sf (Simple Features)\n")
  cat("  - trends_sp (Spatial Points)\n\n")
  
  invisible(list(
    trends_sf = trends_sf,
    trends_sp = trends_sp
  ))
}
