#' Plot Individual Station Trends
#'
#' Creates time series plots for each station showing monthly anomalies
#' with best-fit trend lines and statistics. Saves plots to Figures folder.
#'
#' @param trends Data frame from process_all_stations()
#' @param stations Character vector of station IDs to plot. If NULL, plots all stations.
#' @param max_stations Maximum number of stations to plot (default = 10 to avoid too many files)
#' @param save_plots Logical. Save plots to files (default = TRUE)
#' @param figuresfolder Path to figures folder (default = uses global figuresfolder)
#'
#' @return Invisibly returns list of ggplot objects
#'
#' @examples
#' \dontrun{
#' trends <- process_all_stations()
#' 
#' # Plot first 10 stations
#' plot_station_trends(trends)
#' 
#' # Plot specific stations
#' plot_station_trends(trends, stations = c("USC00045123", "USC00046336"))
#' 
#' # Plot more stations
#' plot_station_trends(trends, max_stations = 20)
#' }
#'
#' @export
plot_station_trends <- function(trends, stations = NULL, max_stations = 10,
                                save_plots = TRUE, figuresfolder = NULL) {
  
  # Check for required data
  if (!exists("station_list", envir = .GlobalEnv)) {
    stop("Run load_stations() first to load station data!")
  }
  
  station_list <- get("station_list", envir = .GlobalEnv)
  
  # Get figures folder
  if (is.null(figuresfolder)) {
    if (exists("figuresfolder", envir = .GlobalEnv)) {
      figuresfolder <- get("figuresfolder", envir = .GlobalEnv)
    } else {
      figuresfolder <- "Figures/"
    }
  }
  
  # Create StationPlots subfolder
  plot_dir <- paste0(figuresfolder, "StationPlots/")
  if (!dir.exists(plot_dir)) {
    dir.create(plot_dir, recursive = TRUE)
  }
  
  # Select which stations to plot
  if (is.null(stations)) {
    stations <- trends$ID[1:min(max_stations, nrow(trends))]
  } else {
    stations <- stations[1:min(length(stations), max_stations)]
  }
  
  cat("===========================================================\n")
  cat("  Plotting Individual Station Trends\n")
  cat("===========================================================\n")
  cat("Stations to plot:", length(stations), "\n")
  cat("Output directory:", plot_dir, "\n\n")
  
  plots <- list()
  
  for (i in 1:length(stations)) {
    station_id <- stations[i]
    
    cat(sprintf("[%d/%d] Plotting %s...\n", i, length(stations), station_id))
    
    # Get station data
    if (!station_id %in% names(station_list)) {
      warning("Station ", station_id, " not found in station_list")
      next
    }
    
    station_data <- station_list[[station_id]]
    
    # Get station metadata from trends
    station_meta <- trends[trends$ID == station_id, ]
    if (nrow(station_meta) == 0) {
      warning("Station ", station_id, " not found in trends")
      next
    }
    
    # Process station
    tryCatch({
      # Clean data
      station_clean <- fixDates.fun(station_data)
      station_clean <- fixValues.fun(station_clean)
      
      # Get monthly values
      monthly <- MonthlyValues.fun(station_clean)
      
      # Get normals and anomalies
      normals <- MonthlyNormals.fun(station_clean)
      anomalies <- MonthlyAnomalies.fun(monthly, normals)
      
      # Create 3-panel plot
      p_tmax <- create_station_panel(anomalies$TMAX, "TMAX.a", 
                                      station_meta$annual_trend_TMAX,
                                      "TMAX Anomaly (°C)", station_id)
      
      p_tmin <- create_station_panel(anomalies$TMIN, "TMIN.a",
                                      station_meta$annual_trend_TMIN,
                                      "TMIN Anomaly (°C)", station_id)
      
      p_prcp <- create_station_panel(anomalies$PRCP, "PRCP.a",
                                      station_meta$annual_trend_PRCP,
                                      "PRCP Anomaly (mm)", station_id)
      
      # Combine panels
      library(patchwork)
      p_combined <- p_tmax / p_tmin / p_prcp +
        patchwork::plot_annotation(
          title = paste("Climate Trends -", station_id),
          subtitle = paste0(station_meta$NAME, " (", 
                           round(station_meta$LATITUDE, 2), ", ",
                           round(station_meta$LONGITUDE, 2), ")")
        )
      
      plots[[station_id]] <- p_combined
      
      # Save plot
      if (save_plots) {
        filename <- paste0(plot_dir, "station_", station_id, ".png")
        ggplot2::ggsave(filename, p_combined, width = 10, height = 12, dpi = 300)
      }
      
    }, error = function(e) {
      warning("Failed to plot station ", station_id, ": ", conditionMessage(e))
    })
  }
  
  cat("\n[OK] Created", length(plots), "station plots\n")
  cat("     Saved to:", plot_dir, "\n")
  cat("===========================================================\n\n")
  
  invisible(plots)
}


#' Create Station Panel Helper
#' @keywords internal
create_station_panel <- function(data, var_name, trend_value, ylabel, station_id) {
  
  # Calculate annual means for plotting
  annual_data <- aggregate(as.formula(paste(var_name, "~ YEAR")), 
                           data = data, mean, na.rm = TRUE)
  
  # Create trend line
  fit <- lm(as.formula(paste(var_name, "~ YEAR")), data = annual_data)
  annual_data$predicted <- predict(fit)
  
  # Create plot
  p <- ggplot2::ggplot(annual_data, ggplot2::aes(x = YEAR, y = .data[[var_name]])) +
    ggplot2::geom_line(color = "gray50", alpha = 0.7) +
    ggplot2::geom_point(color = "steelblue", size = 1.5, alpha = 0.6) +
    ggplot2::geom_line(ggplot2::aes(y = predicted), 
                      color = "red", linewidth = 1) +
    ggplot2::labs(
      y = ylabel,
      x = "Year",
      subtitle = sprintf("Trend: %+.2f per century", trend_value)
    ) +
    ggplot2::theme_minimal() +
    ggplot2::theme(
      plot.subtitle = ggplot2::element_text(color = "red", face = "bold")
    )
  
  return(p)
}


#' Plot Station Point Map with Trends
#'
#' Creates a map showing station locations as points, colored by trend values.
#' This is simpler than kriging and works well with few stations.
#'
#' @param spatial_data Spatial points data frame (sp or sf format)
#' @param trend_var Name of trend variable to display
#' @param title Plot title
#' @param state State abbreviation for boundaries
#' @param point_size Size of station points (default = 3)
#' @param colors Color scheme: "temp" or "precip" (default = "temp")
#'
#' @return ggplot2 object
#'
#' @examples
#' \dontrun{
#' trends <- process_all_stations()
#' create_spatial_objects(trends)
#' 
#' # Point map (good for few stations)
#' map <- plot_station_map(trends_sf, "annual_trend_TMAX",
#'                          "TMAX Trends by Station", state = "CA")
#' print(map)
#' }
#'
#' @export
plot_station_map <- function(spatial_data, trend_var, title,
                             state = NULL, point_size = 3,
                             colors = "temp") {
  
  # Convert to sf if needed
  if (inherits(spatial_data, "Spatial")) {
    spatial_data <- sf::st_as_sf(spatial_data)
  }
  
  # Get state if not provided
  if (is.null(state) && exists("my.state", envir = .GlobalEnv)) {
    state <- get("my.state", envir = .GlobalEnv)
  }
  
  # Check variable exists
  if (!trend_var %in% names(spatial_data)) {
    stop("Variable '", trend_var, "' not found in spatial data")
  }
  
  # Get state boundaries
  state_map <- get_map_data("state", regions = tolower(state))
  
  # Get bounding box
  bbox <- sf::st_bbox(spatial_data)
  buffer <- 0.5
  
  # Create plot
  p <- ggplot2::ggplot() +
    ggplot2::geom_polygon(
      data = state_map,
      ggplot2::aes(x = long, y = lat, group = group),
      fill = "gray95", color = "black", linewidth = 0.5
    ) +
    ggplot2::geom_sf(
      data = spatial_data,
      ggplot2::aes(color = .data[[trend_var]]),
      size = point_size
    ) +
    ggplot2::coord_sf(
      xlim = c(bbox["xmin"] - buffer, bbox["xmax"] + buffer),
      ylim = c(bbox["ymin"] - buffer, bbox["ymax"] + buffer)
    ) +
    ggplot2::labs(
      title = title,
      color = "Trend",
      x = "Longitude",
      y = "Latitude"
    ) +
    ggplot2::theme_minimal()
  
  # Add color scale
  if (colors == "temp") {
    p <- p + ggplot2::scale_color_gradient2(
      low = "blue", mid = "white", high = "red",
      midpoint = 0
    )
  } else {
    p <- p + ggplot2::scale_color_gradient2(
      low = "brown", mid = "white", high = "darkgreen",
      midpoint = 0
    )
  }
  
  return(p)
}


#' Check Station Coverage and Suggest Approach
#'
#' Evaluates whether a state has enough stations for kriging interpolation
#' and suggests the best visualization approach.
#'
#' @param trends Data frame from process_all_stations()
#' @param min_stations_kriging Minimum stations recommended for kriging (default = 20)
#' @param min_stations_warn Minimum stations to issue warning (default = 10)
#'
#' @return List with assessment and recommendations
#'
#' @examples
#' \dontrun{
#' trends <- process_all_stations()
#' assessment <- check_station_coverage(trends)
#' }
#'
#' @export
check_station_coverage <- function(trends, min_stations_kriging = 20,
                                   min_stations_warn = 10) {
  
  n_stations <- nrow(trends)
  n_with_coords <- sum(!is.na(trends$LATITUDE) & !is.na(trends$LONGITUDE))
  
  # Check spatial distribution
  if (n_with_coords > 0) {
    lat_range <- diff(range(trends$LATITUDE, na.rm = TRUE))
    lon_range <- diff(range(trends$LONGITUDE, na.rm = TRUE))
    spatial_extent <- lat_range * lon_range
  } else {
    spatial_extent <- 0
  }
  
  # Assess coverage
  if (n_with_coords < min_stations_warn) {
    status <- "POOR"
    recommendation <- "point_map"
    message <- paste0(
      "WARNING: Very few stations (", n_with_coords, "). ",
      "Use plot_station_map() instead of create_heatmap(). ",
      "Consider combining with neighboring states or using regional data."
    )
  } else if (n_with_coords < min_stations_kriging) {
    status <- "FAIR"
    recommendation <- "point_map_or_simple_kriging"
    message <- paste0(
      "Limited stations (", n_with_coords, "). ",
      "plot_station_map() recommended, or use create_heatmap() with caution. ",
      "Consider using coarser resolution."
    )
  } else {
    status <- "GOOD"
    recommendation <- "kriging"
    message <- paste0(
      "Good coverage (", n_with_coords, " stations). ",
      "create_heatmap() will work well."
    )
  }
  
  # Print assessment
  cat("===========================================================\n")
  cat("  STATION COVERAGE ASSESSMENT\n")
  cat("===========================================================\n")
  cat("Total stations:", n_stations, "\n")
  cat("Stations with coordinates:", n_with_coords, "\n")
  cat("Spatial extent:", round(spatial_extent, 2), "sq degrees\n")
  cat("Status:", status, "\n")
  cat("\nRECOMMENDATION:\n")
  cat(strwrap(message, width = 60, prefix = "  "), sep = "\n")
  cat("===========================================================\n\n")
  
  result <- list(
    n_stations = n_stations,
    n_with_coords = n_with_coords,
    spatial_extent = spatial_extent,
    status = status,
    recommendation = recommendation,
    message = message
  )
  
  return(invisible(result))
}
