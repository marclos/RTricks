#' Process All Stations for Spatial Analysis
#'
#' Loops through all loaded stations, cleans data, calculates normals,
#' anomalies, and trend statistics. Returns a data frame with one row per
#' station containing annual and seasonal trend estimates suitable for mapping.
#'
#' @param verbose Logical. Show progress messages (default TRUE).
#' @param trend_method Character. Which trend estimator to use:
#'   \code{"OLS"} (default, ordinary least squares) or
#'   \code{"Theil-Sen"} (robust non-parametric; see
#'   \code{\link{monthlyTrend_robust.fun}}).
#' @param compute_extreme_precip Logical. If TRUE (default FALSE), also
#'   computes extreme precipitation indices (heavy-day frequency, intensity,
#'   max daily, etc.) and their trends. Adds columns prefixed with
#'   \code{trend_} to the output. See \code{\link{ExtremePrecp.fun}}.
#' @param compute_nonlinear Logical. If TRUE (default FALSE), fits GAM
#'   smooths to annual anomalies and reports effective degrees of freedom.
#'   Useful for detecting acceleration or deceleration of trends.
#'   See \code{\link{nonlinearTrend.fun}}.
#' @param min_days_temp Minimum non-missing days per month for temperature
#'   elements. Passed to \code{\link{MonthlyValues.fun}}. Default 20.
#' @param min_days_prcp Minimum non-missing days per month for precipitation.
#'   Passed to \code{\link{MonthlyValues.fun}}. Default 25.
#'
#' @return Data frame with one row per station. Columns include station metadata
#'   (ID, LATITUDE, LONGITUDE, ELEVATION, NAME), trend variables
#'   (annual_trend_TMAX, etc.), and optionally extreme precipitation trends
#'   and nonlinear diagnostics.
#'
#' @details
#' \strong{v0.3.1 changes:}
#' \itemize{
#'   \item Monthly completeness filtering via \code{min_days_temp} and
#'     \code{min_days_prcp} prevents biased estimates from incomplete months.
#'   \item \code{trend_method = "Theil-Sen"} uses the median pairwise slope
#'     (robust to outliers) with Mann-Kendall significance instead of OLS.
#'   \item \code{compute_extreme_precip = TRUE} adds intensity, heavy-day,
#'     and maximum-daily precipitation trend columns.
#'   \item \code{compute_nonlinear = TRUE} adds GAM effective-degrees-of-freedom
#'     columns that flag stations with non-linear trends.
#' }
#'
#' @examples
#' \dontrun{
#' # Default (backward-compatible with v0.3.0)
#' trends <- process_all_stations()
#'
#' # Robust trends with extreme precipitation
#' trends <- process_all_stations(trend_method = "Theil-Sen",
#'                                compute_extreme_precip = TRUE)
#'
#' # Full analysis including nonlinear diagnostics
#' trends <- process_all_stations(trend_method = "Theil-Sen",
#'                                compute_extreme_precip = TRUE,
#'                                compute_nonlinear = TRUE)
#' }
#'
#' @seealso \code{\link{create_spatial_objects}} for converting results to
#'   spatial format, \code{\link{monthlyTrend_robust.fun}},
#'   \code{\link{ExtremePrecp.fun}}, \code{\link{nonlinearTrend.fun}}
#'
#' @export
process_all_stations <- function(verbose = TRUE,
                                  trend_method = c("OLS", "Theil-Sen"),
                                  compute_extreme_precip = FALSE,
                                  compute_nonlinear = FALSE,
                                  min_days_temp = 20,
                                  min_days_prcp = 25) {

  trend_method <- match.arg(trend_method)

  if (!exists("station_list", envir = .GlobalEnv)) {
    stop("Run load_stations() or load_and_save_stations() first!")
  }

  station_list <- get("station_list", envir = .GlobalEnv)

  # Get station metadata for coordinates
  inv <- NULL
  if (exists("station_inventory", envir = .GlobalEnv)) {
    inv <- get("station_inventory", envir = .GlobalEnv)
  } else if (exists("my.inventory", envir = .GlobalEnv)) {
    inv <- get("my.inventory", envir = .GlobalEnv)
  }

  if (verbose) {
    cat("===========================================================\n")
    cat("  Processing Stations for Spatial Analysis (v0.3.1)\n")
    cat("===========================================================\n")
    cat("Stations to process:", length(station_list), "\n")
    cat("Trend method:", trend_method, "\n")
    cat("Completeness filter: temp >=", min_days_temp,
        "days, prcp >=", min_days_prcp, "days per month\n")
    if (compute_extreme_precip) cat("Extreme precipitation indices: YES\n")
    if (compute_nonlinear)      cat("Nonlinear (GAM) diagnostics: YES\n")
    cat("\n")
  }

  results_list <- list()
  success <- 0
  skipped <- 0

  for (i in seq_along(station_list)) {
    station_id <- names(station_list)[i]
    station_data <- station_list[[station_id]]

    if (verbose) cat(sprintf("[%d/%d] %s ... ", i, length(station_list), station_id))

    tryCatch({
      # Clean dates and values
      station_data <- fixDates.fun(station_data)
      station_data <- fixValues.fun(station_data)

      # Monthly aggregation (v0.3.1: with completeness filter)
      monthly <- MonthlyValues.fun(station_data,
                                    min_days_temp = min_days_temp,
                                    min_days_prcp = min_days_prcp)

      # Normals (with fallback cascade)
      normals <- MonthlyNormals.fun(station_data, station_id = station_id)
      if (is.null(normals)) {
        skipped <- skipped + 1
        if (verbose) cat("SKIPPED (no normals)\n")
        next
      }

      # Anomalies
      anomalies <- MonthlyAnomalies.fun(monthly, normals, station_id = station_id)
      if (is.null(anomalies)) {
        skipped <- skipped + 1
        if (verbose) cat("SKIPPED (no anomalies)\n")
        next
      }

      # Monthly trends (v0.3.1: OLS or Theil-Sen)
      if (trend_method == "Theil-Sen") {
        trends <- monthlyTrend_robust.fun(anomalies)
      } else {
        trends <- monthlyTrend.fun(anomalies)
      }
      if (nrow(trends) == 0) {
        skipped <- skipped + 1
        if (verbose) cat("SKIPPED (no trends)\n")
        next
      }

      # ---- Aggregate to annual & seasonal ----
      row <- data.frame(ID = station_id, stringsAsFactors = FALSE)
      row$trend_method <- trend_method

      for (element in c("TMAX", "TMIN", "PRCP")) {
        elem_trends <- subset(trends, ELEMENT == element)
        if (nrow(elem_trends) == 0) next

        # Annual: mean of all 12 monthly slopes, scaled to per-century
        annual_slope <- mean(elem_trends$Estimate, na.rm = TRUE) * 100
        row[[paste0("annual_trend_", element)]] <- annual_slope

        # Seasonal: mean of seasonal months, scaled to per-century
        winter_months <- c(12, 1, 2)
        spring_months <- c(3, 4, 5)
        summer_months <- c(6, 7, 8)
        fall_months   <- c(9, 10, 11)

        w <- subset(elem_trends, MONTH %in% winter_months)
        s <- subset(elem_trends, MONTH %in% spring_months)
        u <- subset(elem_trends, MONTH %in% summer_months)
        f <- subset(elem_trends, MONTH %in% fall_months)

        if (nrow(w) > 0) row[[paste0("winter_trend_", element)]] <- mean(w$Estimate, na.rm = TRUE) * 100
        if (nrow(s) > 0) row[[paste0("spring_trend_", element)]] <- mean(s$Estimate, na.rm = TRUE) * 100
        if (nrow(u) > 0) row[[paste0("summer_trend_", element)]] <- mean(u$Estimate, na.rm = TRUE) * 100
        if (nrow(f) > 0) row[[paste0("fall_trend_", element)]]   <- mean(f$Estimate, na.rm = TRUE) * 100
      }

      # ---- Extreme precipitation indices (v0.3.1) ----
      if (compute_extreme_precip) {
        extreme <- tryCatch(
          ExtremePrecp.fun(station_data),
          error = function(e) NULL
        )
        if (!is.null(extreme)) {
          # Use matching trend method for extreme indices
          ext_trends <- .fit_extreme_trends(extreme, method = trend_method)
          for (nm in names(ext_trends)) {
            row[[nm]] <- ext_trends[[nm]]
          }
        }
      }

      # ---- Nonlinear trend diagnostics (v0.3.1) ----
      if (compute_nonlinear) {
        nl <- tryCatch(
          nonlinearTrend.fun(anomalies),
          error = function(e) data.frame()
        )
        if (nrow(nl) > 0) {
          for (j in 1:nrow(nl)) {
            elem <- nl$ELEMENT[j]
            row[[paste0("gam_edf_", elem)]]          <- nl$edf[j]
            row[[paste0("gam_dev_explained_", elem)]] <- nl$dev_explained[j]
            row[[paste0("gam_smooth_range_", elem)]]  <- nl$smooth_range[j]
          }
        }
      }

      # Add coordinates from inventory
      if (!is.null(inv) && station_id %in% inv$ID) {
        meta <- inv[inv$ID == station_id, ]
        row$LATITUDE  <- meta$LATITUDE[1]
        row$LONGITUDE <- meta$LONGITUDE[1]
        if ("ELEVATION" %in% names(meta)) row$ELEVATION <- meta$ELEVATION[1]
        if ("NAME" %in% names(meta)) row$NAME <- meta$NAME[1]
      }

      results_list[[station_id]] <- row
      success <- success + 1
      if (verbose) cat("OK\n")

    }, error = function(e) {
      skipped <<- skipped + 1
      if (verbose) cat("ERROR:", conditionMessage(e), "\n")
    })
  }

  # Combine all rows
  if (length(results_list) == 0) {
    stop("No stations were successfully processed.")
  }

  # Use rbind with fill to handle possible missing columns
  all_names <- unique(unlist(lapply(results_list, names)))
  results <- do.call(rbind, lapply(results_list, function(r) {
    missing <- setdiff(all_names, names(r))
    for (m in missing) r[[m]] <- NA
    r[all_names]
  }))
  rownames(results) <- NULL

  if (verbose) {
    cat("\n===========================================================\n")
    cat("Processing Summary:\n")
    cat("===========================================================\n")
    cat("  Trend method:", trend_method, "\n")
    cat("  Successfully processed:", success, "\n")
    cat("  Skipped:", skipped, "\n")
    if ("annual_trend_TMAX" %in% names(results)) {
      cat("  Mean annual TMAX trend:",
          round(mean(results$annual_trend_TMAX, na.rm = TRUE), 2), "deg C/century\n")
    }
    if ("annual_trend_TMIN" %in% names(results)) {
      cat("  Mean annual TMIN trend:",
          round(mean(results$annual_trend_TMIN, na.rm = TRUE), 2), "deg C/century\n")
    }
    if (compute_extreme_precip && "trend_intensity" %in% names(results)) {
      cat("  Mean precip intensity trend:",
          round(mean(results$trend_intensity, na.rm = TRUE), 3), "mm/day per century\n")
      cat("  Mean heavy-day trend:",
          round(mean(results$trend_heavy_days, na.rm = TRUE), 2), "days per century\n")
    }
    if (compute_nonlinear && "gam_edf_TMAX" %in% names(results)) {
      mean_edf <- round(mean(results$gam_edf_TMAX, na.rm = TRUE), 2)
      cat("  Mean GAM edf (TMAX):", mean_edf,
          ifelse(mean_edf > 2, " (nonlinear trends detected)", " (approximately linear)"),
          "\n")
    }
    cat("===========================================================\n\n")
    cat("Next step: create_spatial_objects(trends)\n\n")
  }

  return(results)
}
